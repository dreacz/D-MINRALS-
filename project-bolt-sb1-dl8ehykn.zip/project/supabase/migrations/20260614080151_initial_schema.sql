-- Parties table
CREATE TABLE parties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  address TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE parties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_parties" ON parties FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_parties" ON parties FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_parties" ON parties FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_parties" ON parties FOR DELETE TO authenticated USING (true);

-- Packing/Products table
CREATE TABLE packings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  kg DECIMAL NOT NULL,
  rate_per_kg DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE packings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_packings" ON packings FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_packings" ON packings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_packings" ON packings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_packings" ON packings FOR DELETE TO authenticated USING (true);

-- Bills table
CREATE TABLE bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE,
  party_id UUID REFERENCES parties(id) ON DELETE SET NULL,
  total_amount DECIMAL NOT NULL DEFAULT 0,
  paid_amount DECIMAL NOT NULL DEFAULT 0,
  pending_amount DECIMAL NOT NULL DEFAULT 0,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_bills" ON bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_bills" ON bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_bills" ON bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_bills" ON bills FOR DELETE TO authenticated USING (true);

-- Bill items table
CREATE TABLE bill_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES bills(id) ON DELETE CASCADE,
  packing_id UUID REFERENCES packings(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL,
  kg DECIMAL NOT NULL,
  rate_per_kg DECIMAL NOT NULL,
  amount DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bill_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_bill_items" ON bill_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_bill_items" ON bill_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_bill_items" ON bill_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_bill_items" ON bill_items FOR DELETE TO authenticated USING (true);

-- Payments table
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES bills(id) ON DELETE SET NULL,
  amount DECIMAL NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_payments" ON payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_payments" ON payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_payments" ON payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_payments" ON payments FOR DELETE TO authenticated USING (true);

-- Create index for faster lookups
CREATE INDEX idx_bills_party_id ON bills(party_id);
CREATE INDEX idx_bill_items_bill_id ON bill_items(bill_id);
CREATE INDEX idx_payments_bill_id ON payments(bill_id);