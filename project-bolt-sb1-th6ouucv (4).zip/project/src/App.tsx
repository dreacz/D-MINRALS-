import { useState } from 'react';
import {
  Building2,
  Users,
  Truck,
  Package,
  FileText,
  LayoutDashboard,
  Menu,
  X,
  BarChart3,
  MapPin,
  Layers
} from 'lucide-react';
import { COMPANY_PROFILE } from './lib/supabase';
import Dashboard from './components/Dashboard';
import Parties from './components/Parties';
import Materials from './components/Materials';
import Trucks from './components/Trucks';
import StoneBills from './components/StoneBills';
import StoneBill from './components/StoneBill';
import InstallPrompt from './components/InstallPrompt';
import DailySalesReport from './components/DailySalesReport';
import Sites from './components/Sites';
import BituminousGrades from './components/BituminousGrades';
import AsphaltBills from './components/AsphaltBills';
import AsphaltBill from './components/AsphaltBill';

type View = 'dashboard' | 'parties' | 'materials' | 'trucks' | 'bills' | 'new-bill' | 'edit-bill' | 'view-bill' | 'sales-report'
  | 'sites' | 'bituminous-grades' | 'asphalt-bills' | 'new-asphalt-bill' | 'edit-asphalt-bill' | 'view-asphalt-bill';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedBillId, setSelectedBillId] = useState<string | null>(null);

  const menuItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'bills' as View, label: 'All Bills', icon: FileText },
    { id: 'sales-report' as View, label: 'Sales Report', icon: BarChart3 },
    { id: 'parties' as View, label: 'Parties', icon: Users },
    { id: 'materials' as View, label: 'Materials', icon: Package },
    { id: 'trucks' as View, label: 'Trucks', icon: Truck },
  ];

  const asphaltMenuItems = [
    { id: 'asphalt-bills' as View, label: 'Asphalt Bills', icon: FileText },
    { id: 'sites' as View, label: 'Sites', icon: MapPin },
    { id: 'bituminous-grades' as View, label: 'Bituminous', icon: Layers },
  ];

  const handleNavigate = (view: View, billId?: string) => {
    setCurrentView(view);
    if (billId) setSelectedBillId(billId);
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'parties':
        return <Parties />;
      case 'materials':
        return <Materials />;
      case 'trucks':
        return <Trucks />;
      case 'bills':
        return <StoneBills onNavigate={handleNavigate} />;
      case 'sales-report':
        return <DailySalesReport />;
      case 'new-bill':
        return <StoneBill mode="create" onBack={() => setCurrentView('bills')} />;
      case 'edit-bill':
        return selectedBillId ? (
          <StoneBill mode="edit" billId={selectedBillId} onBack={() => setCurrentView('bills')} />
        ) : null;
      case 'view-bill':
        return selectedBillId ? (
          <StoneBill mode="view" billId={selectedBillId} onBack={() => setCurrentView('bills')} />
        ) : null;
      // Asphalt Components
      case 'sites':
        return <Sites />;
      case 'bituminous-grades':
        return <BituminousGrades />;
      case 'asphalt-bills':
        return <AsphaltBills onNavigate={handleNavigate} />;
      case 'new-asphalt-bill':
        return <AsphaltBill mode="create" onBack={() => setCurrentView('asphalt-bills')} />;
      case 'edit-asphalt-bill':
        return selectedBillId ? (
          <AsphaltBill mode="edit" billId={selectedBillId} onBack={() => setCurrentView('asphalt-bills')} />
        ) : null;
      case 'view-asphalt-bill':
        return selectedBillId ? (
          <AsphaltBill mode="view" billId={selectedBillId} onBack={() => setCurrentView('asphalt-bills')} />
        ) : null;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-20'
        } bg-gradient-to-b from-slate-800 to-slate-900 text-white transition-all duration-300 flex flex-col`}
      >
        {/* Company Header */}
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <img
              src={COMPANY_PROFILE.logo}
              alt={COMPANY_PROFILE.name}
              className="w-12 h-12 object-contain bg-white rounded-lg p-1"
            />
            {sidebarOpen && (
              <div className="overflow-hidden">
                <h1 className="font-bold text-lg leading-tight">{COMPANY_PROFILE.name}</h1>
                <p className="text-xs text-slate-400">{COMPANY_PROFILE.parentCompany}</p>
              </div>
            )}
          </div>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-amber-500 text-slate-900 font-semibold'
                    : 'hover:bg-slate-700 text-slate-300'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span>{item.label}</span>}
              </button>
            );
          })}

          {/* Asphalt Section Divider */}
          {sidebarOpen && (
            <div className="pt-4 pb-2">
              <p className="text-xs text-slate-500 uppercase tracking-wider px-4">Asphalt Module</p>
            </div>
          )}

          {asphaltMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-cyan-500 text-slate-900 font-semibold'
                    : 'hover:bg-slate-700 text-slate-300'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span>{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Company Info */}
        {sidebarOpen && (
          <div className="p-4 border-t border-slate-700 text-xs text-slate-400 space-y-1">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              <span>{COMPANY_PROFILE.location}</span>
            </div>
            <p>GST: {COMPANY_PROFILE.gst}</p>
            <p>Ph: {COMPANY_PROFILE.contact}</p>
          </div>
        )}

        {/* Toggle Button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-4 border-t border-slate-700 hover:bg-slate-700 transition-colors"
        >
          {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderContent()}
        </div>
      </main>

      {/* PWA Install Prompt */}
      <InstallPrompt />
    </div>
  );
}

export default App;
