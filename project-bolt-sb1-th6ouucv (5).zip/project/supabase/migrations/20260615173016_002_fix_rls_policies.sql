-- Drop existing policies
DROP POLICY IF EXISTS select_parties ON parties;
DROP POLICY IF EXISTS insert_parties ON parties;
DROP POLICY IF EXISTS update_parties ON parties;
DROP POLICY IF EXISTS delete_parties ON parties;

DROP POLICY IF EXISTS select_materials ON materials;
DROP POLICY IF EXISTS insert_materials ON materials;
DROP POLICY IF EXISTS update_materials ON materials;
DROP POLICY IF EXISTS delete_materials ON materials;

DROP POLICY IF EXISTS select_trucks ON trucks;
DROP POLICY IF EXISTS insert_trucks ON trucks;
DROP POLICY IF EXISTS update_trucks ON trucks;
DROP POLICY IF EXISTS delete_trucks ON trucks;

DROP POLICY IF EXISTS select_bills ON bills;
DROP POLICY IF EXISTS insert_bills ON bills;
DROP POLICY IF EXISTS update_bills ON bills;
DROP POLICY IF EXISTS delete_bills ON bills;

DROP POLICY IF EXISTS select_payments ON payments;
DROP POLICY IF EXISTS insert_payments ON payments;
DROP POLICY IF EXISTS delete_payments ON payments;

-- Create new policies allowing anon access (internal business tool)
-- Parties
CREATE POLICY "select_parties" ON parties FOR SELECT USING (true);
CREATE POLICY "insert_parties" ON parties FOR INSERT WITH CHECK (true);
CREATE POLICY "update_parties" ON parties FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_parties" ON parties FOR DELETE USING (true);

-- Materials
CREATE POLICY "select_materials" ON materials FOR SELECT USING (true);
CREATE POLICY "insert_materials" ON materials FOR INSERT WITH CHECK (true);
CREATE POLICY "update_materials" ON materials FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_materials" ON materials FOR DELETE USING (true);

-- Trucks
CREATE POLICY "select_trucks" ON trucks FOR SELECT USING (true);
CREATE POLICY "insert_trucks" ON trucks FOR INSERT WITH CHECK (true);
CREATE POLICY "update_trucks" ON trucks FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_trucks" ON trucks FOR DELETE USING (true);

-- Bills
CREATE POLICY "select_bills" ON bills FOR SELECT USING (true);
CREATE POLICY "insert_bills" ON bills FOR INSERT WITH CHECK (true);
CREATE POLICY "update_bills" ON bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_bills" ON bills FOR DELETE USING (true);

-- Payments
CREATE POLICY "select_payments" ON payments FOR SELECT USING (true);
CREATE POLICY "insert_payments" ON payments FOR INSERT WITH CHECK (true);
CREATE POLICY "update_payments" ON payments FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_payments" ON payments FOR DELETE USING (true);