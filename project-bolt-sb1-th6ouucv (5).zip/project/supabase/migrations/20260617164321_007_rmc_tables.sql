-- Create tms (Transit Mixers) table
CREATE TABLE IF NOT EXISTS tms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tm_number TEXT NOT NULL UNIQUE,
  tm_code TEXT,
  wheel_count INTEGER DEFAULT 10,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create concrete_grades table
CREATE TABLE IF NOT EXISTS concrete_grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grade_name TEXT NOT NULL,
  price_per_mqb DECIMAL(12,2) DEFAULT 0,
  carting_bhadu DECIMAL(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rmc_bills table
CREATE TABLE IF NOT EXISTS rmc_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL,
  bill_date DATE NOT NULL DEFAULT CURRENT_DATE,
  site_id uuid REFERENCES sites(id),
  tm_id uuid REFERENCES tms(id),
  concrete_grade_id uuid REFERENCES concrete_grades(id),
  quantity_mqb DECIMAL(12,3) DEFAULT 0,
  rate_per_mqb DECIMAL(12,2) DEFAULT 0,
  carting_bhadu DECIMAL(12,2) DEFAULT 0,
  material_amount DECIMAL(12,2) DEFAULT 0,
  carting_amount DECIMAL(12,2) DEFAULT 0,
  total_amount DECIMAL(12,2) DEFAULT 0,
  payment_amount DECIMAL(12,2) DEFAULT 0,
  pending_amount DECIMAL(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tms ENABLE ROW LEVEL SECURITY;
ALTER TABLE concrete_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE rmc_bills ENABLE ROW LEVEL SECURITY;

-- RLS Policies for tms (anonymous access)
CREATE POLICY "anon_select_tms" ON tms FOR SELECT USING (true);
CREATE POLICY "anon_insert_tms" ON tms FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_tms" ON tms FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_tms" ON tms FOR DELETE USING (true);

-- RLS Policies for concrete_grades (anonymous access)
CREATE POLICY "anon_select_concrete_grades" ON concrete_grades FOR SELECT USING (true);
CREATE POLICY "anon_insert_concrete_grades" ON concrete_grades FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_concrete_grades" ON concrete_grades FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_concrete_grades" ON concrete_grades FOR DELETE USING (true);

-- RLS Policies for rmc_bills (anonymous access)
CREATE POLICY "anon_select_rmc_bills" ON rmc_bills FOR SELECT USING (true);
CREATE POLICY "anon_insert_rmc_bills" ON rmc_bills FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_rmc_bills" ON rmc_bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_rmc_bills" ON rmc_bills FOR DELETE USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tms_number ON tms(tm_number);
CREATE INDEX IF NOT EXISTS idx_concrete_grades_name ON concrete_grades(grade_name);
CREATE INDEX IF NOT EXISTS idx_rmc_bills_bill_date ON rmc_bills(bill_date);
CREATE INDEX IF NOT EXISTS idx_rmc_bills_site ON rmc_bills(site_id);