-- Parties table
CREATE TABLE parties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  mobile_number TEXT,
  address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Materials table
CREATE TABLE materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  rate_per_ton DECIMAL(10,2) NOT NULL DEFAULT 0,
  royalty_per_ton DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trucks table
CREATE TABLE trucks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  truck_number TEXT NOT NULL UNIQUE,
  wheel_count INTEGER DEFAULT 10,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bills table
CREATE TABLE bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE,
  party_id UUID REFERENCES parties(id) ON DELETE SET NULL,
  material_id UUID REFERENCES materials(id) ON DELETE SET NULL,
  truck_id UUID REFERENCES trucks(id) ON DELETE SET NULL,
  royalty_number TEXT,
  gross_weight_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
  tare_weight_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
  net_weight_ton DECIMAL(12,4) NOT NULL DEFAULT 0,
  royalty_ton DECIMAL(12,4) NOT NULL DEFAULT 0,
  royalty_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  payment_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  pending_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  bill_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Payments table
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES bills(id) ON DELETE CASCADE,
  amount DECIMAL(12,2) NOT NULL,
  payment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE trucks ENABLE ROW LEVEL SECURITY;
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for parties
CREATE POLICY "select_parties" ON parties FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_parties" ON parties FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_parties" ON parties FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_parties" ON parties FOR DELETE TO authenticated USING (true);

-- RLS Policies for materials
CREATE POLICY "select_materials" ON materials FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_materials" ON materials FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_materials" ON materials FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_materials" ON materials FOR DELETE TO authenticated USING (true);

-- RLS Policies for trucks
CREATE POLICY "select_trucks" ON trucks FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_trucks" ON trucks FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_trucks" ON trucks FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_trucks" ON trucks FOR DELETE TO authenticated USING (true);

-- RLS Policies for bills
CREATE POLICY "select_bills" ON bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_bills" ON bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_bills" ON bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_bills" ON bills FOR DELETE TO authenticated USING (true);

-- RLS Policies for payments
CREATE POLICY "select_payments" ON payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_payments" ON payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "delete_payments" ON payments FOR DELETE TO authenticated USING (true);

-- Create index for faster bill number lookups
CREATE INDEX idx_bills_bill_number ON bills(bill_number);
CREATE INDEX idx_bills_party_id ON bills(party_id);
CREATE INDEX idx_bills_bill_date ON bills(bill_date);