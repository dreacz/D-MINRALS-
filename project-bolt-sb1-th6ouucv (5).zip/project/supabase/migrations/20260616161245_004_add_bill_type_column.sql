-- Add bill_type column to bills table
ALTER TABLE bills ADD COLUMN IF NOT EXISTS bill_type TEXT DEFAULT 'aggregate_sell';

-- Create bill_types enum check constraint
ALTER TABLE bills ADD CONSTRAINT bill_type_check 
CHECK (bill_type IN ('aggregate_sell', 'aggregate_purchase', 'stone_sell', 'stone_purchase'));

-- Update existing bills to have default type
UPDATE bills SET bill_type = 'aggregate_sell' WHERE bill_type IS NULL;

-- Create index for bill_type
CREATE INDEX IF NOT EXISTS idx_bills_bill_type ON bills(bill_type);