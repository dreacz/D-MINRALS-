// D MINERALS CO. - Service Worker for PWA
const CACHE_NAME = 'd-minerals-v1';
const STATIC_CACHE = 'd-minerals-static-v1';
const DYNAMIC_CACHE = 'd-minerals-dynamic-v1';

// Static assets to cache immediately
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// External resources to cache
const EXTERNAL_ASSETS = [
  'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...');

  event.waitUntil(
    Promise.all([
      // Cache static assets
      caches.open(STATIC_CACHE).then((cache) => {
        console.log('[Service Worker] Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      }),
      // Cache external assets
      caches.open(DYNAMIC_CACHE).then((cache) => {
        console.log('[Service Worker] Caching external assets');
        return Promise.all(
          EXTERNAL_ASSETS.map((url) =>
            fetch(url, { mode: 'cors' })
              .then((response) => {
                if (response.ok) {
                  return cache.put(url, response);
                }
              })
              .catch(() => {
                console.log('[Service Worker] Failed to cache:', url);
              })
          )
        );
      })
    ]).then(() => {
      console.log('[Service Worker] Installation complete');
      return self.skipWaiting();
    })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...');

  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('[Service Worker] Activation complete');
      return self.clients.claim();
    })
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Handle API requests (Supabase) - Network first, then cache
  if (url.origin.includes('supabase.co')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Clone the response
          const responseClone = response.clone();

          // Cache the response
          caches.open(DYNAMIC_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });

          return response;
        })
        .catch(() => {
          // If offline, try cache
          return caches.match(request);
        })
    );
    return;
  }

  // Handle static assets - Cache first, then network
  if (request.destination === 'style' ||
      request.destination === 'script' ||
      request.destination === 'image' ||
      request.destination === 'font') {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        if (cachedResponse) {
          // Return cached, and update cache in background
          fetch(request).then((response) => {
            caches.open(DYNAMIC_CACHE).then((cache) => {
              cache.put(request, response);
            });
          }).catch(() => {});

          return cachedResponse;
        }

        // Not in cache, fetch from network
        return fetch(request).then((response) => {
          const responseClone = response.clone();
          caches.open(DYNAMIC_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });
          return response;
        });
      })
    );
    return;
  }

  // Handle navigation requests - Network first, fallback to cache
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          return response;
        })
        .catch(() => {
          return caches.match('/index.html');
        })
    );
    return;
  }

  // Default: Stale while revalidate
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request).then((response) => {
        const responseClone = response.clone();
        caches.open(DYNAMIC_CACHE).then((cache) => {
          cache.put(request, responseClone);
        });
        return response;
      });

      return cachedResponse || fetchPromise;
    })
  );
});

// Handle background sync for offline bills
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Background sync:', event.tag);

  if (event.tag === 'sync-bills') {
    event.waitUntil(syncBills());
  }
});

// Sync bills when online
async function syncBills() {
  try {
    const clients = await self.clients.matchAll();
    clients.forEach((client) => {
      client.postMessage({
        type: 'SYNC_COMPLETE',
        message: 'Bills synced successfully'
      });
    });
  } catch (error) {
    console.error('[Service Worker] Sync failed:', error);
  }
}

// Push notifications (for future use)
self.addEventListener('push', (event) => {
  const options = {
    body: event.data?.text() || 'New notification from D MINERALS CO.',
    icon: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png',
    badge: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    }
  };

  event.waitUntil(
    self.registration.showNotification('D MINERALS CO.', options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  event.waitUntil(
    clients.openWindow('/')
  );
});

// Message handler
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});

console.log('[Service Worker] Service Worker loaded');
