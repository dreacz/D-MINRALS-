import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Party = {
  id: string;
  name: string;
  mobile_number: string | null;
  address: string | null;
  created_at: string;
  updated_at: string;
};

export type Material = {
  id: string;
  name: string;
  rate_per_ton: number;
  royalty_per_ton: number;
  created_at: string;
  updated_at: string;
};

export type Truck = {
  id: string;
  truck_number: string;
  wheel_count: number;
  created_at: string;
  updated_at: string;
};

export type Bill = {
  id: string;
  bill_number: string;
  party_id: string | null;
  material_id: string | null;
  truck_id: string | null;
  royalty_number: string | null;
  gross_weight_kg: number;
  tare_weight_kg: number;
  net_weight_ton: number;
  royalty_ton: number;
  royalty_amount: number;
  total_amount: number;
  payment_amount: number;
  pending_amount: number;
  bill_date: string;
  created_at: string;
  updated_at: string;
  party?: Party;
  material?: Material;
  truck?: Truck;
};

export type Payment = {
  id: string;
  bill_id: string;
  amount: number;
  payment_date: string;
  notes: string | null;
  created_at: string;
};

export const COMPANY_PROFILE = {
  name: 'D MINERALS CO.',
  parentCompany: 'D ROCK SAND',
  location: 'SEVALIYA',
  gst: '24NTF192Q7GM1Z',
  contact: '9737468847',
  logo: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png'
};
