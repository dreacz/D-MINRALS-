import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Printer,
  IndianRupee,
  Search,
  FileText,
  Receipt
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface RMCBillData {
  id: string;
  bill_number: string;
  bill_date: string;
  quantity_mqb: number;
  rate_per_mqb: number;
  carting_bhadu: number;
  material_amount: number;
  carting_amount: number;
  total_amount: number;
  payment_amount: number;
  pending_amount: number;
  site: { site_name: string; site_number: string } | null;
  tm: { tm_number: string; tm_code: string | null } | null;
  concrete_grade: { grade_name: string } | null;
}

type View = 'dashboard' | 'sites' | 'tms' | 'concrete-grades' | 'rmc-bills' | 'new-rmc-bill' | 'edit-rmc-bill' | 'view-rmc-bill';

interface RMCBillsProps {
  onNavigate: (view: View, billId?: string) => void;
}

export default function RMCBills({ onNavigate }: RMCBillsProps) {
  const [bills, setBills] = useState<RMCBillData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchBills();
  }, []);

  const fetchBills = async () => {
    try {
      const { data } = await supabase
        .from('rmc_bills')
        .select(`
          id,
          bill_number,
          bill_date,
          quantity_mqb,
          rate_per_mqb,
          carting_bhadu,
          material_amount,
          carting_amount,
          total_amount,
          payment_amount,
          pending_amount,
          site:sites(site_name, site_number),
          tm:tms(tm_number, tm_code),
          concrete_grade:concrete_grades(grade_name)
        `)
        .order('created_at', { ascending: false });

      setBills(data || []);
    } catch (error) {
      console.error('Error fetching bills:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this bill?')) return;
    try {
      await supabase.from('rmc_bills').delete().eq('id', id);
      fetchBills();
    } catch (error) {
      console.error('Error deleting bill:', error);
    }
  };

  const filteredBills = bills.filter((bill) =>
    bill.bill_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.site?.site_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.concrete_grade?.grade_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate totals
  const totals = bills.reduce(
    (acc, bill) => ({
      totalAmount: acc.totalAmount + (bill.total_amount || 0),
      totalMqb: acc.totalMqb + (bill.quantity_mqb || 0),
      pendingAmount: acc.pendingAmount + (bill.pending_amount || 0),
      count: acc.count + 1
    }),
    { totalAmount: 0, totalMqb: 0, pendingAmount: 0, count: 0 }
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrint = (bill: RMCBillData) => {
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>RMC Bill - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .title-bar { background: #fff; border: 2px solid #000; color: #000; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; border: 1px solid #000; }
          .site-info { margin: 20px 0; padding: 15px; border: 1px solid #000; }
          .site-name { font-size: 16px; font-weight: bold; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .amount-section { margin: 20px 0; padding: 15px; border: 1px solid #000; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>

        <div class="title-bar">READY MIX CONCRETE BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${bill.bill_number}</div>
          <div><strong>Date:</strong> ${bill.bill_date}</div>
        </div>

        <div class="site-info">
          <div class="site-name">${bill.site?.site_name || 'N/A'}</div>
        </div>

        <div class="info-row">
          <span><strong>Grade:</strong> ${bill.concrete_grade?.grade_name || '-'}</span>
          <span><strong>TM:</strong> ${bill.tm?.tm_number || 'No TM'}</span>
        </div>

        <div class="info-row">
          <span><strong>Quantity:</strong> ${bill.quantity_mqb || 0} MQB</span>
          <span><strong>Rate:</strong> ${formatCurrency(bill.rate_per_mqb || 0)}/MQB</span>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount</span>
            <span>${formatCurrency(bill.material_amount || 0)}</span>
          </div>
          <div class="amount-row">
            <span>Karting Bhadu</span>
            <span>${formatCurrency(bill.carting_amount || 0)}</span>
          </div>
          <div class="amount-row total">
            <span>Total</span>
            <span>${formatCurrency(bill.total_amount || 0)}</span>
          </div>
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleGatePass = (bill: RMCBillData) => {
    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Gate Pass - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 300px; margin: 0 auto; font-size: 11px; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 8px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .title { border: 1px solid #000; padding: 5px; margin: 8px -10px; text-align: center; font-weight: bold; }
          .row { display: flex; justify-content: space-between; margin: 4px 0; }
          .total { font-weight: bold; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>
        <div class="title">GATE PASS</div>
        <div class="row"><span>Bill No:</span><span>${bill.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${bill.bill_date}</span></div>
        <div class="row"><span>Site:</span><span>${bill.site?.site_name || '-'}</span></div>
        <div class="row"><span>Grade:</span><span>${bill.concrete_grade?.grade_name || '-'}</span></div>
        <div class="row"><span>TM:</span><span>${bill.tm?.tm_number || '-'}</span></div>
        <div class="row"><span>Qty:</span><span>${bill.quantity_mqb || 0} MQB</span></div>
        <div class="total row"><span>Total:</span><span>${formatCurrency(bill.total_amount || 0)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-gray-800 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">RMC Bills</h1>
            <p className="text-gray-500 text-sm">{totals.count} bills recorded</p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('new-rmc-bill')}
          className="flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-xl font-semibold hover:bg-gray-800 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          New Bill
        </button>
      </div>

      {/* Summary Cards - Black & White */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Total Bills</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{totals.count}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Total Amount</p>
          <p className="text-2xl font-bold text-gray-900 mt-2">{formatCurrency(totals.totalAmount)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Total MQB</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{totals.totalMqb.toFixed(3)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Pending Amount</p>
          <p className="text-2xl font-bold text-gray-900 mt-2">{formatCurrency(totals.pendingAmount)}</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search by bill number, site, grade..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-900">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Site</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Grade</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">TM</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Qty (MQB)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Total</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Pending</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-white uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredBills.map((bill) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap font-bold text-gray-900">#{bill.bill_number}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.site?.site_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.concrete_grade?.grade_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.tm?.tm_number || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-medium text-gray-900">{(bill.quantity_mqb || 0).toFixed(3)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatCurrency(bill.total_amount || 0)}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-gray-900' : 'text-gray-500'}`}>
                    {formatCurrency(bill.pending_amount || 0)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => handlePrint(bill)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Print Bill"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleGatePass(bill)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Gate Pass"
                      >
                        <Receipt className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onNavigate('edit-rmc-bill', bill.id)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Edit Bill"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(bill.id)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Delete Bill"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-gray-500">
                    No RMC bills found. Create your first bill to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
