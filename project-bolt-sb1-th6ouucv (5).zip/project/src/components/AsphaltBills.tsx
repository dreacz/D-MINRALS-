import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Printer,
  IndianRupee,
  Search,
  FileText,
  CreditCard,
  Receipt
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface AsphaltBillData {
  id: string;
  bill_number: string;
  bill_date: string;
  quantity_ton: number;
  rate_per_ton: number;
  carting_bhadu: number;
  material_amount: number;
  carting_amount: number;
  total_amount: number;
  payment_amount: number;
  pending_amount: number;
  site: { site_name: string; site_number: string } | null;
  bituminous_grade: { grade_name: string } | null;
  truck: { truck_number: string; wheel_count: number } | null;
}

type View = 'dashboard' | 'sites' | 'bituminous-grades' | 'asphalt-bills' | 'new-asphalt-bill' | 'edit-asphalt-bill' | 'view-asphalt-bill';

interface AsphaltBillsProps {
  onNavigate: (view: View, billId?: string) => void;
}

export default function AsphaltBills({ onNavigate }: AsphaltBillsProps) {
  const [bills, setBills] = useState<AsphaltBillData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchBills();
  }, []);

  const fetchBills = async () => {
    try {
      const { data } = await supabase
        .from('asphalt_bills')
        .select(`
          id,
          bill_number,
          bill_date,
          quantity_ton,
          rate_per_ton,
          carting_bhadu,
          material_amount,
          carting_amount,
          total_amount,
          payment_amount,
          pending_amount,
          site:sites(site_name, site_number),
          bituminous_grade:bituminous_grades(grade_name),
          truck:trucks(truck_number, wheel_count)
        `)
        .order('created_at', { ascending: false });

      setBills(data || []);
    } catch (error) {
      console.error('Error fetching bills:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this bill?')) return;
    try {
      await supabase.from('asphalt_bills').delete().eq('id', id);
      fetchBills();
    } catch (error) {
      console.error('Error deleting bill:', error);
    }
  };

  const getTruckDisplay = (truck: AsphaltBillData['truck']) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  const filteredBills = bills.filter((bill) =>
    bill.bill_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.site?.site_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.bituminous_grade?.grade_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate totals
  const totals = bills.reduce(
    (acc, bill) => ({
      totalAmount: acc.totalAmount + (bill.total_amount || 0),
      totalTons: acc.totalTons + (bill.quantity_ton || 0),
      pendingAmount: acc.pendingAmount + (bill.pending_amount || 0),
      count: acc.count + 1
    }),
    { totalAmount: 0, totalTons: 0, pendingAmount: 0, count: 0 }
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrint = (bill: AsphaltBillData) => {
    const truckInfo = getTruckDisplay(bill.truck);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Asphalt Bill - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .title-bar { background: #0891b2; color: #fff; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; }
          .site-info { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
          .site-name { font-size: 16px; font-weight: bold; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .amount-section { margin: 20px 0; padding: 15px; background: #f5f5f5; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>

        <div class="title-bar">ASPHALT BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${bill.bill_number}</div>
          <div><strong>Date:</strong> ${bill.bill_date}</div>
        </div>

        <div class="site-info">
          <div class="site-name">${bill.site?.site_name || 'N/A'}</div>
        </div>

        <div class="info-row">
          <span><strong>Grade:</strong> ${bill.bituminous_grade?.grade_name || '-'}</span>
          <span><strong>Truck:</strong> ${truckInfo.number}</span>
        </div>

        <div class="info-row">
          <span><strong>Quantity:</strong> ${bill.quantity_ton || 0} Ton</span>
          <span><strong>Rate:</strong> ${formatCurrency(bill.rate_per_ton || 0)}/Ton</span>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount</span>
            <span>${formatCurrency(bill.material_amount || 0)}</span>
          </div>
          <div class="amount-row">
            <span>Karting Bhadu</span>
            <span>${formatCurrency(bill.carting_amount || 0)}</span>
          </div>
          <div class="amount-row total">
            <span>Total</span>
            <span>${formatCurrency(bill.total_amount || 0)}</span>
          </div>
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleGatePass = (bill: AsphaltBillData) => {
    const truckInfo = getTruckDisplay(bill.truck);

    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Gate Pass - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 300px; margin: 0 auto; font-size: 11px; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 8px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .title { background: #0891b2; color: #fff; padding: 5px; margin: 8px -10px; text-align: center; font-weight: bold; }
          .row { display: flex; justify-content: space-between; margin: 4px 0; }
          .total { font-weight: bold; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>
        <div class="title">GATE PASS</div>
        <div class="row"><span>Bill No:</span><span>${bill.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${bill.bill_date}</span></div>
        <div class="row"><span>Site:</span><span>${bill.site?.site_name || '-'}</span></div>
        <div class="row"><span>Grade:</span><span>${bill.bituminous_grade?.grade_name || '-'}</span></div>
        <div class="row"><span>Truck:</span><span>${truckInfo.number}</span></div>
        <div class="row"><span>Qty:</span><span>${bill.quantity_ton || 0} Ton</span></div>
        <div class="total row"><span>Total:</span><span>${formatCurrency(bill.total_amount || 0)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-cyan-100 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-cyan-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Asphalt Bills</h1>
            <p className="text-gray-500 text-sm">{totals.count} bills recorded</p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('new-asphalt-bill')}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-xl font-semibold hover:from-cyan-600 hover:to-cyan-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          New Bill
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white">
          <p className="text-blue-100 text-sm font-medium">Total Bills</p>
          <p className="text-3xl font-bold mt-2">{totals.count}</p>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-5 text-white">
          <p className="text-green-100 text-sm font-medium">Total Amount</p>
          <p className="text-2xl font-bold mt-2">{formatCurrency(totals.totalAmount)}</p>
        </div>
        <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-xl p-5 text-white">
          <p className="text-cyan-100 text-sm font-medium">Total Tons</p>
          <p className="text-3xl font-bold mt-2">{totals.totalTons.toFixed(3)}</p>
        </div>
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-5 text-white">
          <p className="text-red-100 text-sm font-medium">Pending Amount</p>
          <p className="text-2xl font-bold mt-2">{formatCurrency(totals.pendingAmount)}</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search by bill number, site, grade..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Site</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Grade</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Truck</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Qty (Ton)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Pending</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBills.map((bill) => {
                const truckInfo = getTruckDisplay(bill.truck);
                return (
                  <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap font-bold text-gray-900">#{bill.bill_number}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.site?.site_name || '-'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bituminous_grade?.grade_name || '-'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{truckInfo.number} ({truckInfo.wheels}W)</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-medium text-gray-900">{(bill.quantity_ton || 0).toFixed(3)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatCurrency(bill.total_amount || 0)}</td>
                    <td className={`px-4 py-3 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {formatCurrency(bill.pending_amount || 0)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handlePrint(bill)}
                          className="p-1.5 text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors"
                          title="Print Bill"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleGatePass(bill)}
                          className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title="Gate Pass"
                        >
                          <Receipt className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onNavigate('edit-asphalt-bill', bill.id)}
                          className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                          title="Edit Bill"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(bill.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Bill"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-gray-500">
                    No asphalt bills found. Create your first bill to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
