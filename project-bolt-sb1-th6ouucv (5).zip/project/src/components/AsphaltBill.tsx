import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Printer,
  Save,
  IndianRupee,
  Truck,
  Layers,
  MapPin,
  Scale,
  FileText,
  Hash,
  Receipt
} from 'lucide-react';
import { supabase, Truck as TruckType, COMPANY_PROFILE } from '../lib/supabase';

interface Site {
  id: string;
  site_name: string;
  site_number: string;
  site_location: string | null;
  site_incharge: string | null;
}

interface BituminousGrade {
  id: string;
  grade_name: string;
  price_per_ton: number;
  carting_bhadu: number;
}

interface AsphaltBillProps {
  mode: 'create' | 'edit' | 'view';
  billId?: string;
  onBack: () => void;
}

export default function AsphaltBill({ mode, billId, onBack }: AsphaltBillProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sites, setSites] = useState<Site[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [trucks, setTrucks] = useState<TruckType[]>([]);
  const [lastBillNumber, setLastBillNumber] = useState(0);

  const [formData, setFormData] = useState({
    bill_number: '',
    bill_date: new Date().toISOString().split('T')[0],
    site_id: '',
    bituminous_grade_id: '',
    truck_id: '',
    quantity_ton: '',
    payment_amount: ''
  });

  const [selectedSite, setSelectedSite] = useState<Site | null>(null);
  const [selectedGrade, setSelectedGrade] = useState<BituminousGrade | null>(null);

  const [calculated, setCalculated] = useState({
    rate_per_ton: 0,
    carting_bhadu: 0,
    material_amount: 0,
    carting_amount: 0,
    total_amount: 0,
    pending_amount: 0
  });

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const site = sites.find(s => s.id === formData.site_id);
    setSelectedSite(site || null);
  }, [formData.site_id, sites]);

  useEffect(() => {
    const grade = grades.find(g => g.id === formData.bituminous_grade_id);
    setSelectedGrade(grade || null);
    if (grade) {
      setCalculated(prev => ({
        ...prev,
        rate_per_ton: grade.price_per_ton,
        carting_bhadu: grade.carting_bhadu
      }));
    }
  }, [formData.bituminous_grade_id, grades]);

  useEffect(() => {
    calculateAmounts();
  }, [formData.quantity_ton, formData.payment_amount, selectedGrade]);

  const fetchData = async () => {
    try {
      const [sitesRes, gradesRes, trucksRes, billsRes] = await Promise.all([
        supabase.from('sites').select('*').order('site_name'),
        supabase.from('bituminous_grades').select('*').order('grade_name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('asphalt_bills').select('bill_number').order('created_at', { ascending: false }).limit(1)
      ]);

      setSites(sitesRes.data || []);
      setGrades(gradesRes.data || []);
      setTrucks(trucksRes.data || []);

      if (billsRes.data && billsRes.data.length > 0) {
        const lastNum = parseInt(billsRes.data[0].bill_number) || 0;
        setLastBillNumber(lastNum);
        setFormData(prev => ({
          ...prev,
          bill_number: String(lastNum + 1).padStart(4, '0')
        }));
      } else {
        setFormData(prev => ({ ...prev, bill_number: '0001' }));
      }

      if (billId && (mode === 'edit' || mode === 'view')) {
        const { data: billData } = await supabase
          .from('asphalt_bills')
          .select('*')
          .eq('id', billId)
          .single();

        if (billData) {
          setFormData({
            bill_number: billData.bill_number,
            bill_date: billData.bill_date,
            site_id: billData.site_id || '',
            bituminous_grade_id: billData.bituminous_grade_id || '',
            truck_id: billData.truck_id || '',
            quantity_ton: billData.quantity_ton?.toString() || '',
            payment_amount: billData.payment_amount?.toString() || ''
          });
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAmounts = () => {
    const quantityTon = parseFloat(formData.quantity_ton) || 0;
    const paymentAmount = parseFloat(formData.payment_amount) || 0;

    if (selectedGrade) {
      const materialAmount = quantityTon * selectedGrade.price_per_ton;
      const cartingAmount = quantityTon * selectedGrade.carting_bhadu;
      const totalAmount = materialAmount + cartingAmount;

      setCalculated(prev => ({
        ...prev,
        material_amount: materialAmount,
        carting_amount: cartingAmount,
        total_amount: totalAmount,
        pending_amount: totalAmount - paymentAmount
      }));
    }
  };

  const handleSubmit = async () => {
    if (!formData.site_id) {
      alert('Please select a Site');
      return;
    }
    if (!formData.bituminous_grade_id) {
      alert('Please select a Bituminous Grade');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        bill_number: formData.bill_number,
        bill_date: formData.bill_date,
        site_id: formData.site_id,
        bituminous_grade_id: formData.bituminous_grade_id,
        truck_id: formData.truck_id === 'no-vehicle' ? null : formData.truck_id || null,
        quantity_ton: parseFloat(formData.quantity_ton) || 0,
        rate_per_ton: calculated.rate_per_ton,
        carting_bhadu: calculated.carting_bhadu,
        material_amount: calculated.material_amount,
        carting_amount: calculated.carting_amount,
        total_amount: calculated.total_amount,
        payment_amount: parseFloat(formData.payment_amount) || 0,
        pending_amount: calculated.pending_amount,
        updated_at: new Date().toISOString()
      };

      if (mode === 'edit' && billId) {
        await supabase
          .from('asphalt_bills')
          .update(payload)
          .eq('id', billId);
      } else {
        await supabase.from('asphalt_bills').insert([payload]);
      }

      onBack();
    } catch (error) {
      console.error('Error saving bill:', error);
      alert('Error saving bill. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getTruckDisplay = (truck: TruckType | null | undefined) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  const handlePrint = () => {
    const selectedTruck = formData.truck_id === 'no-vehicle' ? null : trucks.find(t => t.id === formData.truck_id);
    const truckInfo = getTruckDisplay(selectedTruck);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Asphalt Bill - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title-bar { background: #0891b2; color: #fff; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; }
          .site-info { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
          .site-name { font-size: 16px; font-weight: bold; margin-bottom: 10px; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .amount-section { margin: 20px 0; padding: 15px; background: #f5f5f5; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; padding: 5px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 12px; text-align: center; color: #666; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title-bar">ASPHALT BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${formData.bill_number}</div>
          <div><strong>Date:</strong> ${formData.bill_date}</div>
        </div>

        <div class="site-info">
          <div class="site-name">${selectedSite?.site_name || 'N/A'}</div>
          <div class="info-row"><span>Site Number:</span><span>${selectedSite?.site_number || '-'}</span></div>
          ${selectedSite?.site_location ? `<div class="info-row"><span>Location:</span><span>${selectedSite.site_location}</span></div>` : ''}
          ${selectedSite?.site_incharge ? `<div class="info-row"><span>Incharge:</span><span>${selectedSite.site_incharge}</span></div>` : ''}
        </div>

        <div class="info-row">
          <span><strong>Bituminous Grade:</strong> ${selectedGrade?.grade_name || 'N/A'}</span>
          <span><strong>Truck:</strong> ${truckInfo.number}</span>
        </div>

        <div class="info-row">
          <span><strong>Quantity:</strong> ${formData.quantity_ton || 0} Ton</span>
          <span><strong>Rate:</strong> ${formatCurrency(calculated.rate_per_ton)}/Ton</span>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount (${formData.quantity_ton || 0} Ton x ${formatCurrency(calculated.rate_per_ton)})</span>
            <span>${formatCurrency(calculated.material_amount)}</span>
          </div>
          <div class="amount-row">
            <span>Karting Bhadu (${formData.quantity_ton || 0} Ton x ${formatCurrency(calculated.carting_bhadu)})</span>
            <span>${formatCurrency(calculated.carting_amount)}</span>
          </div>
          <div class="amount-row total">
            <span>Total Amount</span>
            <span>${formatCurrency(calculated.total_amount)}</span>
          </div>
          ${parseFloat(formData.payment_amount || '0') > 0 ? `
          <div class="amount-row">
            <span>Payment Received</span>
            <span>${formatCurrency(parseFloat(formData.payment_amount || '0'))}</span>
          </div>
          <div class="amount-row" style="font-weight: bold; color: #dc2626;">
            <span>Balance Due</span>
            <span>${formatCurrency(calculated.pending_amount)}</span>
          </div>
          ` : ''}
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleSlipPrint = () => {
    const selectedTruck = formData.truck_id === 'no-vehicle' ? null : trucks.find(t => t.id === formData.truck_id);
    const truckInfo = getTruckDisplay(selectedTruck);

    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Gate Pass - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 300px; margin: 0 auto; font-size: 11px; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 8px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .title { background: #0891b2; color: #fff; padding: 5px; margin: 8px -10px; text-align: center; font-weight: bold; }
          .row { display: flex; justify-content: space-between; margin: 4px 0; }
          .total { font-weight: bold; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>
        <div class="title">GATE PASS</div>
        <div class="row"><span>Bill No:</span><span>${formData.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${formData.bill_date}</span></div>
        <div class="row"><span>Site:</span><span>${selectedSite?.site_name || '-'}</span></div>
        <div class="row"><span>Grade:</span><span>${selectedGrade?.grade_name || '-'}</span></div>
        <div class="row"><span>Truck:</span><span>${truckInfo.number}</span></div>
        <div class="row"><span>Quantity:</span><span>${formData.quantity_ton || 0} Ton</span></div>
        <div class="total row"><span>Total:</span><span>${formatCurrency(calculated.total_amount)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const isViewMode = mode === 'view';
  const isEditMode = mode === 'edit' || mode === 'create';

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {mode === 'create' ? 'New Asphalt Bill' : mode === 'edit' ? 'Edit Bill' : 'View Bill'}
            </h1>
            <p className="text-gray-500 text-sm">Asphalt Material Bill</p>
          </div>
        </div>
        <div className="flex gap-2">
          {isViewMode && (
            <>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-xl font-semibold hover:from-cyan-600 hover:to-cyan-700 transition-all"
              >
                <Printer className="w-4 h-4" />
                Print A4
              </button>
              <button
                onClick={handleSlipPrint}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                <Receipt className="w-4 h-4" />
                Gate Pass
              </button>
            </>
          )}
          {isEditMode && (
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-xl font-semibold hover:from-cyan-600 hover:to-cyan-700 transition-all shadow-lg disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : 'Save Bill'}
            </button>
          )}
        </div>
      </div>

      {/* Bill Info */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Bill Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Hash className="w-4 h-4 inline mr-1" />
              Bill Number
            </label>
            <input
              type="text"
              value={formData.bill_number}
              onChange={(e) => setFormData({ ...formData, bill_number: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100 font-mono font-bold"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="w-4 h-4 inline mr-1" />
              Bill Date
            </label>
            <input
              type="date"
              value={formData.bill_date}
              onChange={(e) => setFormData({ ...formData, bill_date: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Truck className="w-4 h-4 inline mr-1" />
              Truck
            </label>
            <select
              value={formData.truck_id}
              onChange={(e) => setFormData({ ...formData, truck_id: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="">Select Truck</option>
              <option value="no-vehicle">No Vehicle</option>
              {trucks.map(t => (
                <option key={t.id} value={t.id}>{t.truck_number} ({t.wheel_count || 0}W)</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Site Selection */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-purple-500" />
          Site Details
        </h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Select Site *</label>
          <select
            value={formData.site_id}
            onChange={(e) => setFormData({ ...formData, site_id: e.target.value })}
            disabled={isViewMode}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100"
          >
            <option value="">Select Site</option>
            {sites.map(s => (
              <option key={s.id} value={s.id}>{s.site_name} - #{s.site_number}</option>
            ))}
          </select>
          {selectedSite && (
            <div className="mt-3 p-4 bg-purple-50 rounded-xl">
              <p className="font-semibold text-purple-900">{selectedSite.site_name}</p>
              <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-purple-700">
                <p><strong>Site No:</strong> {selectedSite.site_number}</p>
                <p><strong>Location:</strong> {selectedSite.site_location || 'N/A'}</p>
                <p><strong>Incharge:</strong> {selectedSite.site_incharge || 'N/A'}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bituminous Grade Selection */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Layers className="w-5 h-5 text-cyan-500" />
          Bituminous Grade
        </h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Select Grade *</label>
          <select
            value={formData.bituminous_grade_id}
            onChange={(e) => setFormData({ ...formData, bituminous_grade_id: e.target.value })}
            disabled={isViewMode}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100"
          >
            <option value="">Select Bituminous Grade</option>
            {grades.map(g => (
              <option key={g.id} value={g.id}>{g.grade_name} - {formatCurrency(g.price_per_ton)}/Ton</option>
            ))}
          </select>
          {selectedGrade && (
            <div className="mt-3 p-4 bg-cyan-50 rounded-xl">
              <p className="font-semibold text-cyan-900">{selectedGrade.grade_name}</p>
              <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-cyan-700">
                <p><strong>Rate:</strong> {formatCurrency(selectedGrade.price_per_ton)}/Ton</p>
                <p><strong>Karting:</strong> {formatCurrency(selectedGrade.carting_bhadu)}/Ton</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quantity & Calculations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Scale className="w-5 h-5 text-cyan-500" />
            Quantity
          </h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity (Ton) *</label>
            <input
              type="number"
              min="0"
              step="0.001"
              value={formData.quantity_ton}
              onChange={(e) => setFormData({ ...formData, quantity_ton: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100 text-2xl font-bold text-center"
              placeholder="0.000"
            />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <IndianRupee className="w-5 h-5 text-cyan-500" />
            Calculations
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Material Amount</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.material_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Karting Bhadu</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.carting_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-xl text-white">
              <span className="font-semibold">Total Amount</span>
              <span className="text-2xl font-bold">{formatCurrency(calculated.total_amount)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Payment Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Payment Amount (Rs)</label>
            <input
              type="number"
              min="0"
              step="1"
              value={formData.payment_amount}
              onChange={(e) => setFormData({ ...formData, payment_amount: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="0"
            />
          </div>
          <div className="flex items-center justify-center p-4 bg-green-50 rounded-xl">
            <div className="text-center">
              <p className="text-green-700 text-sm">Payment Received</p>
              <p className="text-2xl font-bold text-green-700">{formatCurrency(parseFloat(formData.payment_amount || '0'))}</p>
            </div>
          </div>
          <div className={`flex items-center justify-center p-4 rounded-xl ${calculated.pending_amount > 0 ? 'bg-red-50' : 'bg-green-100'}`}>
            <div className="text-center">
              <p className={`text-sm ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-green-700'}`}>
                {calculated.pending_amount > 0 ? 'Balance Due' : 'Fully Paid'}
              </p>
              <p className={`text-2xl font-bold ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-green-700'}`}>
                {formatCurrency(Math.max(0, calculated.pending_amount))}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
