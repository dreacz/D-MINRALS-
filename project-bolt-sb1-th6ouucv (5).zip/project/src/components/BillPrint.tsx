import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Printer,
  Save,
  IndianRupee,
  Truck,
  Package,
  User,
  Scale,
  FileText,
  Hash
} from 'lucide-react';
import { supabase, Party, Material, Truck as TruckType, COMPANY_PROFILE } from '../lib/supabase';

interface BillPrintProps {
  mode: 'create' | 'edit' | 'view';
  billId?: string;
  onBack: () => void;
}

export default function BillPrint({ mode, billId, onBack }: BillPrintProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [parties, setParties] = useState<Party[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [trucks, setTrucks] = useState<TruckType[]>([]);
  const [lastBillNumber, setLastBillNumber] = useState('00000');

  const [formData, setFormData] = useState({
    bill_number: '',
    bill_date: new Date().toISOString().split('T')[0],
    party_id: '',
    material_id: '',
    truck_id: '',
    royalty_number: '',
    gross_weight_kg: '',
    tare_weight_kg: '',
    royalty_ton: ''
  });

  const [calculated, setCalculated] = useState({
    net_weight_ton: 0,
    royalty_amount: 0,
    total_amount: 0,
    rate_per_ton: 0,
    royalty_per_ton: 0
  });

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    calculateAmounts();
  }, [formData.gross_weight_kg, formData.tare_weight_kg, formData.royalty_ton, formData.material_id, materials]);

  const fetchData = async () => {
    try {
      const [partiesRes, materialsRes, trucksRes, billsRes] = await Promise.all([
        supabase.from('parties').select('*').order('name'),
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('bills').select('bill_number').order('created_at', { ascending: false }).limit(1)
      ]);

      setParties(partiesRes.data || []);
      setMaterials(materialsRes.data || []);
      setTrucks(trucksRes.data || []);

      if (billsRes.data && billsRes.data.length > 0) {
        const lastNum = parseInt(billsRes.data[0].bill_number) || 0;
        setLastBillNumber(billsRes.data[0].bill_number);
        setFormData(prev => ({
          ...prev,
          bill_number: String(lastNum + 1).padStart(5, '0')
        }));
      } else {
        setFormData(prev => ({ ...prev, bill_number: '00001' }));
      }

      if (billId && (mode === 'edit' || mode === 'view')) {
        const { data: billData } = await supabase
          .from('bills')
          .select('*')
          .eq('id', billId)
          .single();

        if (billData) {
          setFormData({
            bill_number: billData.bill_number,
            bill_date: billData.bill_date,
            party_id: billData.party_id || '',
            material_id: billData.material_id || '',
            truck_id: billData.truck_id || '',
            royalty_number: billData.royalty_number || '',
            gross_weight_kg: billData.gross_weight_kg?.toString() || '',
            tare_weight_kg: billData.tare_weight_kg?.toString() || '',
            royalty_ton: billData.royalty_ton?.toString() || ''
          });
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAmounts = () => {
    const grossWeight = parseFloat(formData.gross_weight_kg) || 0;
    const tareWeight = parseFloat(formData.tare_weight_kg) || 0;
    const royaltyTon = parseFloat(formData.royalty_ton) || 0;
    const netWeightTon = (grossWeight - tareWeight) / 1000;
    const material = materials.find(m => m.id === formData.material_id);

    if (material) {
      const ratePerTon = material.rate_per_ton;
      const royaltyPerTon = material.royalty_per_ton;
      const royaltyAmount = royaltyTon * royaltyPerTon;
      const totalAmount = (netWeightTon * ratePerTon) + royaltyAmount;

      setCalculated({
        net_weight_ton: Math.max(0, netWeightTon),
        royalty_amount: royaltyAmount,
        total_amount: totalAmount,
        rate_per_ton: ratePerTon,
        royalty_per_ton: royaltyPerTon
      });
    }
  };

  const handleSubmit = async () => {
    if (!formData.party_id || !formData.material_id) {
      alert('Please select Party and Material');
      return;
    }

    if (!formData.truck_id) {
      alert('Please select a Truck or "No Vehicle"');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        bill_number: formData.bill_number,
        bill_date: formData.bill_date,
        party_id: formData.party_id || null,
        material_id: formData.material_id || null,
        truck_id: formData.truck_id === 'no-vehicle' ? null : formData.truck_id,
        royalty_number: formData.royalty_number || null,
        gross_weight_kg: parseFloat(formData.gross_weight_kg) || 0,
        tare_weight_kg: parseFloat(formData.tare_weight_kg) || 0,
        net_weight_ton: calculated.net_weight_ton,
        royalty_ton: parseFloat(formData.royalty_ton) || 0,
        royalty_amount: calculated.royalty_amount,
        total_amount: calculated.total_amount,
        payment_amount: 0,
        pending_amount: calculated.total_amount,
        updated_at: new Date().toISOString()
      };

      if (mode === 'edit' && billId) {
        await supabase.from('bills').update(payload).eq('id', billId);
      } else {
        await supabase.from('bills').insert([payload]);
      }

      onBack();
    } catch (error) {
      console.error('Error saving bill:', error);
      alert('Failed to save bill. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2
    }).format(amount);
  };

  const handlePrint = (blackAndWhite: boolean = false) => {
    const selectedParty = parties.find(p => p.id === formData.party_id);
    const selectedMaterial = materials.find(m => m.id === formData.material_id);
    const selectedTruck = formData.truck_id === 'no-vehicle' ? null : trucks.find(t => t.id === formData.truck_id);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bill - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; ${blackAndWhite ? 'filter: grayscale(100%);' : ''} }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title-bar { background: ${blackAndWhite ? '#ccc' : '#f59e0b'}; color: ${blackAndWhite ? '#000' : '#fff'}; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; }
          .party-info { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
          .party-name { font-size: 16px; font-weight: bold; margin-bottom: 10px; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .weight-section { margin: 20px 0; }
          .weight-table { width: 100%; border-collapse: collapse; margin: 10px 0; }
          .weight-table th, .weight-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          .weight-table th { background: #f5f5f5; }
          .amount-section { margin: 20px 0; padding: 15px; background: #f5f5f5; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; padding: 5px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 12px; text-align: center; color: #666; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title-bar">AGGREGATE MATERIAL BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${formData.bill_number}</div>
          <div><strong>Date:</strong> ${formData.bill_date}</div>
        </div>

        <div class="party-info">
          <div class="party-name">${selectedParty?.name || 'N/A'}</div>
          ${selectedParty?.mobile_number ? `<div class="info-row"><span>Mobile:</span><span>${selectedParty.mobile_number}</span></div>` : ''}
          ${selectedParty?.address ? `<div class="info-row"><span>Address:</span><span>${selectedParty.address}</span></div>` : ''}
        </div>

        <div class="info-row">
          <span><strong>Material:</strong> ${selectedMaterial?.name || 'N/A'}</span>
          <span><strong>Rate:</strong> ${formatCurrency(calculated.rate_per_ton)}/Ton</span>
        </div>

        <div class="info-row">
          <span><strong>Truck No:</strong> ${selectedTruck?.truck_number || 'No Vehicle'}</span>
          <span><strong>Wheels:</strong> ${selectedTruck?.wheel_count || 0}</span>
        </div>

        ${formData.royalty_number ? `<div class="info-row"><span><strong>Royalty No:</strong> ${formData.royalty_number}</span></div>` : ''}

        <div class="weight-section">
          <table class="weight-table">
            <tr>
              <th>Gross Weight</th>
              <th>Tare Weight</th>
              <th>Net Weight</th>
            </tr>
            <tr>
              <td>${formData.gross_weight_kg} Kg</td>
              <td>${formData.tare_weight_kg} Kg</td>
              <td>${calculated.net_weight_ton.toFixed(3)} Ton</td>
            </tr>
          </table>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount (${calculated.net_weight_ton.toFixed(3)} Ton x ${formatCurrency(calculated.rate_per_ton)})</span>
            <span>${formatCurrency(calculated.net_weight_ton * calculated.rate_per_ton)}</span>
          </div>
          <div class="amount-row">
            <span>Royalty Amount (${formData.royalty_ton || 0} Ton x ${formatCurrency(calculated.royalty_per_ton)})</span>
            <span>${formatCurrency(calculated.royalty_amount)}</span>
          </div>
          <div class="amount-row total">
            <span>GRAND TOTAL</span>
            <span>${formatCurrency(calculated.total_amount)}</span>
          </div>
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
          <p>Terms & Conditions Apply</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  const isViewMode = mode === 'view';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {mode === 'create' ? 'New Bill' : mode === 'edit' ? 'Edit Bill' : 'Bill Preview'}
            </h1>
            <p className="text-gray-500 text-sm">Bill No: {formData.bill_number}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {!isViewMode && (
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : 'Save Bill'}
            </button>
          )}
          <button
            onClick={() => handlePrint(false)}
            className="flex items-center gap-2 px-4 py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 transition-all"
          >
            <Printer className="w-5 h-5" />
            Print
          </button>
          <button
            onClick={() => handlePrint(true)}
            className="flex items-center gap-2 px-4 py-3 bg-gray-600 text-white rounded-xl font-semibold hover:bg-gray-700 transition-all"
          >
            <Printer className="w-5 h-5" />
            B&W Print
          </button>
        </div>
      </div>

      {/* Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Bill Info */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-amber-500" />
              Bill Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bill Number</label>
                <input
                  type="text"
                  value={formData.bill_number}
                  onChange={(e) => setFormData({ ...formData, bill_number: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bill Date</label>
                <input
                  type="date"
                  value={formData.bill_date}
                  onChange={(e) => setFormData({ ...formData, bill_date: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Royalty Number</label>
                <input
                  type="text"
                  value={formData.royalty_number}
                  onChange={(e) => setFormData({ ...formData, royalty_number: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                  placeholder="Optional"
                />
              </div>
            </div>
          </div>

          {/* Selections */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4">Select Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <User className="w-4 h-4 inline mr-1" />
                  Party *
                </label>
                <select
                  value={formData.party_id}
                  onChange={(e) => setFormData({ ...formData, party_id: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                >
                  <option value="">Select Party</option>
                  {parties.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Package className="w-4 h-4 inline mr-1" />
                  Material *
                </label>
                <select
                  value={formData.material_id}
                  onChange={(e) => setFormData({ ...formData, material_id: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                >
                  <option value="">Select Material</option>
                  {materials.map(m => (
                    <option key={m.id} value={m.id}>{m.name} - {formatCurrency(m.rate_per_ton)}/ton</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Truck className="w-4 h-4 inline mr-1" />
                  Truck *
                </label>
                <select
                  value={formData.truck_id}
                  onChange={(e) => setFormData({ ...formData, truck_id: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none disabled:bg-gray-100"
                >
                  <option value="">Select Truck</option>
                  <option value="no-vehicle">No Vehicle</option>
                  {trucks.map(t => (
                    <option key={t.id} value={t.id}>{t.truck_number} ({t.wheel_count || 0} Wheel)</option>
                  ))}
                </select>
                {formData.truck_id && formData.truck_id !== 'no-vehicle' && (
                  <p className="text-xs text-gray-500 mt-1">
                    {trucks.find(t => t.id === formData.truck_id)?.wheel_count || 0} Wheel Vehicle
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Weights */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Scale className="w-5 h-5 text-green-500" />
              Weight Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Gross Weight (Kg) *</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.gross_weight_kg}
                  onChange={(e) => setFormData({ ...formData, gross_weight_kg: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tare Weight (Kg) *</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.tare_weight_kg}
                  onChange={(e) => setFormData({ ...formData, tare_weight_kg: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Royalty (Ton)</label>
                <input
                  type="number"
                  min="0"
                  step="0.001"
                  value={formData.royalty_ton}
                  onChange={(e) => setFormData({ ...formData, royalty_ton: e.target.value })}
                  disabled={isViewMode}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
                  placeholder="0.000"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 sticky top-8">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <IndianRupee className="w-5 h-5 text-amber-500" />
              Bill Summary
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Net Weight</span>
                <span className="font-medium">{calculated.net_weight_ton.toFixed(3)} Ton</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Rate/Ton</span>
                <span className="font-medium">{formatCurrency(calculated.rate_per_ton)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Material Amount</span>
                <span className="font-medium">{formatCurrency(calculated.net_weight_ton * calculated.rate_per_ton)}</span>
              </div>
              <hr />
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Royalty/Ton</span>
                <span className="font-medium">{formatCurrency(calculated.royalty_per_ton)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Royalty Amount</span>
                <span className="font-medium">{formatCurrency(calculated.royalty_amount)}</span>
              </div>
              <hr />
              <div className="flex justify-between text-lg font-bold">
                <span>Total Amount</span>
                <span className="text-green-600">{formatCurrency(calculated.total_amount)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
