import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Eye,
  Printer,
  IndianRupee,
  Search,
  Calendar,
  FileText,
  CreditCard
} from 'lucide-react';
import { supabase, Bill } from '../lib/supabase';
import PaymentModal from './PaymentModal';

type View = 'dashboard' | 'parties' | 'materials' | 'trucks' | 'bills' | 'new-bill' | 'edit-bill' | 'print-bill';

interface BillsProps {
  onNavigate: (view: View, billId?: string) => void;
}

export default function Bills({ onNavigate }: BillsProps) {
  const [bills, setBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentModal, setPaymentModal] = useState<{ open: boolean; bill: any | null }>({
    open: false,
    bill: null
  });

  const getTruckDisplay = (truck: any) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  useEffect(() => {
    fetchBills();
  }, []);

  const fetchBills = async () => {
    try {
      const { data } = await supabase
        .from('bills')
        .select(`
          id,
          bill_number,
          bill_date,
          gross_weight_kg,
          tare_weight_kg,
          net_weight_ton,
          royalty_ton,
          royalty_amount,
          total_amount,
          payment_amount,
          pending_amount,
          royalty_number,
          party:parties(id, name, mobile_number, address),
          material:materials(id, name, rate_per_ton, royalty_per_ton),
          truck:trucks(id, truck_number, wheel_count)
        `)
        .order('created_at', { ascending: false });
      setBills(data || []);
    } catch (error) {
      console.error('Error fetching bills:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this bill?')) return;
    try {
      await supabase.from('bills').delete().eq('id', id);
      fetchBills();
    } catch (error) {
      console.error('Error deleting bill:', error);
    }
  };

  const handlePaymentSuccess = async (billId: string, amount: number) => {
    // Update bill payment amount and pending amount
    const bill = bills.find(b => b.id === billId);
    if (bill) {
      const newPaymentAmount = bill.payment_amount + amount;
      const newPendingAmount = bill.total_amount - newPaymentAmount;

      await supabase
        .from('bills')
        .update({
          payment_amount: newPaymentAmount,
          pending_amount: Math.max(0, newPendingAmount)
        })
        .eq('id', billId);

      fetchBills();
    }
    setPaymentModal({ open: false, bill: null });
  };

  const filteredBills = bills.filter((bill) =>
    bill.bill_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.party?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    getTruckDisplay(bill.truck).number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const totalAmount = bills.reduce((sum, b) => sum + (b.total_amount || 0), 0);
  const totalPending = bills.reduce((sum, b) => sum + (b.pending_amount || 0), 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-amber-100 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Bills</h1>
            <p className="text-gray-500 text-sm">{bills.length} bills generated</p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('new-bill')}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          New Bill
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-lg border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Bills</p>
              <p className="text-2xl font-bold text-gray-900">{bills.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-100" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Amount</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(totalAmount)}</p>
            </div>
            <IndianRupee className="w-8 h-8 text-green-100" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Pending</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(totalPending)}</p>
            </div>
            <CreditCard className="w-8 h-8 text-red-100" />
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search by bill number, party name, or truck number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Party</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Material</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Truck</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Net (Ton)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Pending</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBills.map((bill) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className="font-semibold text-gray-900">{bill.bill_number}</span>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.party?.name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.material?.name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{getTruckDisplay(bill.truck).number} ({getTruckDisplay(bill.truck).wheels}W)</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-medium text-gray-900">{bill.net_weight_ton?.toFixed(3) || '0.000'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatCurrency(bill.total_amount)}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {formatCurrency(bill.pending_amount)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center justify-center gap-0.5">
                      <button
                        onClick={() => onNavigate('print-bill', bill.id)}
                        className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Print Bill"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onNavigate('edit-bill', bill.id)}
                        className="p-1.5 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                        title="Edit Bill"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setPaymentModal({ open: true, bill })}
                        className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                        title="Add Payment"
                      >
                        <IndianRupee className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(bill.id)}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Bill"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-gray-500">
                    {searchTerm ? 'No bills found matching your search.' : 'No bills found. Create your first bill to get started.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      {paymentModal.open && paymentModal.bill && (
        <PaymentModal
          bill={paymentModal.bill}
          onClose={() => setPaymentModal({ open: false, bill: null })}
          onSuccess={(amount) => handlePaymentSuccess(paymentModal.bill.id, amount)}
        />
      )}
    </div>
  );
}
