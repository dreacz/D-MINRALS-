import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Printer,
  Save,
  IndianRupee,
  Truck,
  Package,
  User,
  Scale,
  FileText,
  Hash,
  Palette,
  Receipt
} from 'lucide-react';
import { supabase, Party, Material, Truck as TruckType, COMPANY_PROFILE } from '../lib/supabase';

interface StoneBillProps {
  mode: 'create' | 'edit' | 'view';
  billId?: string;
  onBack: () => void;
}

type BillType = 'stone_sell' | 'stone_purchase' | 'aggregate_sell' | 'aggregate_purchase';

const BILL_TYPE_LABELS: Record<BillType, string> = {
  'stone_sell': 'Stone Sell',
  'stone_purchase': 'Stone Purchase',
  'aggregate_sell': 'Aggregate Sell',
  'aggregate_purchase': 'Aggregate Purchase'
};

export default function StoneBill({ mode, billId, onBack }: StoneBillProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [parties, setParties] = useState<Party[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [trucks, setTrucks] = useState<TruckType[]>([]);
  const [lastBillNumber, setLastBillNumber] = useState(0);

  const [formData, setFormData] = useState({
    bill_number: '',
    bill_date: new Date().toISOString().split('T')[0],
    bill_type: 'stone_sell' as BillType,
    party_id: '',
    material_id: '',
    truck_id: '',
    royalty_number: '',
    gross_weight_kg: '',
    tare_weight_kg: '',
    royalty_ton: '',
    payment_amount: ''
  });

  const [calculated, setCalculated] = useState({
    net_weight_ton: 0,
    royalty_amount: 0,
    total_amount: 0,
    rate_per_ton: 0,
    royalty_per_ton: 0,
    pending_amount: 0
  });

  const [selectedParty, setSelectedParty] = useState<Party | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const party = parties.find(p => p.id === formData.party_id);
    setSelectedParty(party || null);
  }, [formData.party_id, parties]);

  useEffect(() => {
    calculateAmounts();
  }, [formData.gross_weight_kg, formData.tare_weight_kg, formData.royalty_ton, formData.material_id, formData.payment_amount, materials]);

  const fetchData = async () => {
    try {
      const [partiesRes, materialsRes, trucksRes, billsRes] = await Promise.all([
        supabase.from('parties').select('*').order('name'),
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('bills').select('bill_number').order('created_at', { ascending: false }).limit(1)
      ]);

      setParties(partiesRes.data || []);
      setMaterials(materialsRes.data || []);
      setTrucks(trucksRes.data || []);

      if (billsRes.data && billsRes.data.length > 0) {
        const lastNum = parseInt(billsRes.data[0].bill_number) || 0;
        setLastBillNumber(lastNum);
        setFormData(prev => ({
          ...prev,
          bill_number: String(lastNum + 1).padStart(5, '0')
        }));
      } else {
        setFormData(prev => ({ ...prev, bill_number: '00001' }));
      }

      if (billId && (mode === 'edit' || mode === 'view')) {
        const { data: billData } = await supabase
          .from('bills')
          .select('*')
          .eq('id', billId)
          .single();

        if (billData) {
          setFormData({
            bill_number: billData.bill_number,
            bill_date: billData.bill_date,
            bill_type: billData.bill_type || 'stone_sell',
            party_id: billData.party_id || '',
            material_id: billData.material_id || '',
            truck_id: billData.truck_id || '',
            royalty_number: billData.royalty_number || '',
            gross_weight_kg: billData.gross_weight_kg?.toString() || '',
            tare_weight_kg: billData.tare_weight_kg?.toString() || '',
            royalty_ton: billData.royalty_ton?.toString() || '',
            payment_amount: billData.payment_amount?.toString() || ''
          });
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAmounts = () => {
    const grossWeight = parseFloat(formData.gross_weight_kg) || 0;
    const tareWeight = parseFloat(formData.tare_weight_kg) || 0;
    const royaltyTon = parseFloat(formData.royalty_ton) || 0;
    const paymentAmount = parseFloat(formData.payment_amount) || 0;
    const netWeightTon = (grossWeight - tareWeight) / 1000;
    const material = materials.find(m => m.id === formData.material_id);

    if (material) {
      const ratePerTon = material.rate_per_ton;
      const royaltyPerTon = material.royalty_per_ton;
      const royaltyAmount = royaltyTon * royaltyPerTon;
      const totalAmount = (netWeightTon * ratePerTon) + royaltyAmount;

      setCalculated({
        net_weight_ton: Math.max(0, netWeightTon),
        royalty_amount: royaltyAmount,
        total_amount: totalAmount,
        rate_per_ton: ratePerTon,
        royalty_per_ton: royaltyPerTon,
        pending_amount: totalAmount - paymentAmount
      });
    } else {
      setCalculated(prev => ({
        ...prev,
        net_weight_ton: Math.max(0, netWeightTon),
        pending_amount: prev.total_amount - paymentAmount
      }));
    }
  };

  const handleSubmit = async () => {
    if (!formData.party_id || !formData.material_id) {
      alert('Please select Party and Material');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        bill_number: formData.bill_number,
        bill_date: formData.bill_date,
        bill_type: formData.bill_type,
        party_id: formData.party_id || null,
        material_id: formData.material_id || null,
        truck_id: formData.truck_id === 'no-vehicle' ? null : formData.truck_id || null,
        royalty_number: formData.royalty_number || null,
        gross_weight_kg: parseFloat(formData.gross_weight_kg) || 0,
        tare_weight_kg: parseFloat(formData.tare_weight_kg) || 0,
        net_weight_ton: calculated.net_weight_ton,
        royalty_ton: parseFloat(formData.royalty_ton) || 0,
        royalty_amount: calculated.royalty_amount,
        total_amount: calculated.total_amount,
        payment_amount: parseFloat(formData.payment_amount) || 0,
        pending_amount: calculated.pending_amount,
        updated_at: new Date().toISOString()
      };

      if (mode === 'edit' && billId) {
        await supabase
          .from('bills')
          .update(payload)
          .eq('id', billId);
      } else {
        await supabase.from('bills').insert([payload]);
      }

      onBack();
    } catch (error) {
      console.error('Error saving bill:', error);
      alert('Error saving bill. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getTruckDisplay = (truck: TruckType | null | undefined) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  const handlePrint = (blackAndWhite: boolean = false) => {
    const selectedMaterial = materials.find(m => m.id === formData.material_id);
    const selectedTruck = formData.truck_id === 'no-vehicle' ? null : trucks.find(t => t.id === formData.truck_id);
    const truckInfo = getTruckDisplay(selectedTruck);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bill - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; ${blackAndWhite ? 'filter: grayscale(100%);' : ''} }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title-bar { background: ${blackAndWhite ? '#ccc' : '#f59e0b'}; color: ${blackAndWhite ? '#000' : '#fff'}; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; }
          .party-info { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
          .party-name { font-size: 16px; font-weight: bold; margin-bottom: 10px; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .weight-section { margin: 20px 0; }
          .weight-table { width: 100%; border-collapse: collapse; margin: 10px 0; }
          .weight-table th, .weight-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          .weight-table th { background: #f5f5f5; }
          .amount-section { margin: 20px 0; padding: 15px; background: #f5f5f5; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; padding: 5px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .payment-row { background: #e0f2fe; padding: 10px; margin-top: 10px; border-radius: 5px; }
          .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 12px; text-align: center; color: #666; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title-bar">${BILL_TYPE_LABELS[formData.bill_type].toUpperCase()} BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${formData.bill_number}</div>
          <div><strong>Date:</strong> ${formData.bill_date}</div>
        </div>

        <div class="party-info">
          <div class="party-name">${selectedParty?.name || 'N/A'}</div>
          ${selectedParty?.mobile_number ? `<div class="info-row"><span>Mobile:</span><span>${selectedParty.mobile_number}</span></div>` : ''}
          ${selectedParty?.address ? `<div class="info-row"><span>Address:</span><span>${selectedParty.address}</span></div>` : ''}
        </div>

        <div class="info-row">
          <span><strong>Material:</strong> ${selectedMaterial?.name || 'N/A'}</span>
          <span><strong>Rate:</strong> ${formatCurrency(calculated.rate_per_ton)}/Ton</span>
        </div>

        <div class="info-row">
          <span><strong>Truck No:</strong> ${truckInfo.number}</span>
          <span><strong>Wheels:</strong> ${truckInfo.wheels}</span>
        </div>

        ${formData.royalty_number ? `<div class="info-row"><span><strong>Royalty No:</strong> ${formData.royalty_number}</span></div>` : ''}

        <div class="weight-section">
          <table class="weight-table">
            <tr>
              <th>Gross Weight</th>
              <th>Tare Weight</th>
              <th>Net Weight</th>
            </tr>
            <tr>
              <td>${formData.gross_weight_kg || 0} Kg</td>
              <td>${formData.tare_weight_kg || 0} Kg</td>
              <td>${calculated.net_weight_ton.toFixed(3)} Ton</td>
            </tr>
          </table>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount (${calculated.net_weight_ton.toFixed(3)} Ton x ${formatCurrency(calculated.rate_per_ton)})</span>
            <span>${formatCurrency(calculated.net_weight_ton * calculated.rate_per_ton)}</span>
          </div>
          <div class="amount-row">
            <span>Royalty Amount (${formData.royalty_ton || 0} Ton x ${formatCurrency(calculated.royalty_per_ton)})</span>
            <span>${formatCurrency(calculated.royalty_amount)}</span>
          </div>
          <div class="amount-row total">
            <span>GRAND TOTAL</span>
            <span>${formatCurrency(calculated.total_amount)}</span>
          </div>
          ${parseFloat(formData.payment_amount || '0') > 0 ? `
          <div class="payment-row">
            <div class="amount-row">
              <span>Payment Received</span>
              <span>${formatCurrency(parseFloat(formData.payment_amount || '0'))}</span>
            </div>
            <div class="amount-row" style="font-weight: bold; color: #dc2626;">
              <span>Pending Amount</span>
              <span>${formatCurrency(calculated.pending_amount)}</span>
            </div>
          </div>
          ` : ''}
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
          <p>Terms & Conditions Apply</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleSlipPrint = () => {
    const selectedMaterial = materials.find(m => m.id === formData.material_id);
    const selectedTruck = formData.truck_id === 'no-vehicle' ? null : trucks.find(t => t.id === formData.truck_id);
    const truckInfo = getTruckDisplay(selectedTruck);

    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Slip - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 400px; margin: 0 auto; font-size: 12px; }
          .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .row { display: flex; justify-content: space-between; margin: 5px 0; padding: 3px 0; }
          .total { font-weight: bold; font-size: 14px; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div>${COMPANY_PROFILE.location}</div>
        </div>
        <div class="row"><span>Bill No:</span><span>${formData.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${formData.bill_date}</span></div>
        <div class="row"><span>Party:</span><span>${selectedParty?.name || '-'}</span></div>
        <div class="row"><span>Material:</span><span>${selectedMaterial?.name || '-'}</span></div>
        <div class="row"><span>Truck:</span><span>${truckInfo.number}</span></div>
        <div class="row"><span>Gross:</span><span>${formData.gross_weight_kg || 0} Kg</span></div>
        <div class="row"><span>Tare:</span><span>${formData.tare_weight_kg || 0} Kg</span></div>
        <div class="row"><span>Net:</span><span>${calculated.net_weight_ton.toFixed(3)} Ton</span></div>
        <div class="total row"><span>TOTAL:</span><span>${formatCurrency(calculated.total_amount)}</span></div>
        <div class="row"><span>Payment:</span><span>${formatCurrency(parseFloat(formData.payment_amount || '0'))}</span></div>
        <div class="row" style="font-weight: bold;"><span>Pending:</span><span>${formatCurrency(calculated.pending_amount)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handlePaymentSlipPrint = () => {
    if (parseFloat(formData.payment_amount || '0') <= 0) {
      alert('Please enter a payment amount first.');
      return;
    }

    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Payment Receipt - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 15px; }
          .logo { width: 60px; height: 60px; margin-bottom: 5px; }
          .company-name { font-weight: bold; font-size: 16px; }
          .title { background: #000; color: #fff; padding: 8px; margin: 15px -20px; text-align: center; font-weight: bold; }
          .row { display: flex; justify-content: space-between; margin: 8px 0; }
          .amount-box { background: #f5f5f5; padding: 15px; margin: 15px 0; text-align: center; }
          .amount { font-size: 24px; font-weight: bold; }
          .footer { margin-top: 20px; border-top: 1px dashed #000; padding-top: 10px; font-size: 10px; text-align: center; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div style="font-size: 11px;">${COMPANY_PROFILE.location}</div>
        </div>
        <div class="title">PAYMENT RECEIPT</div>
        <div class="row"><span>Bill No:</span><span>${formData.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${formData.bill_date}</span></div>
        <div class="row"><span>Party:</span><span>${selectedParty?.name || '-'}</span></div>
        <div class="row"><span>Bill Amount:</span><span>${formatCurrency(calculated.total_amount)}</span></div>
        <div class="amount-box">
          <div style="font-size: 12px; color: #666;">AMOUNT RECEIVED</div>
          <div class="amount">${formatCurrency(parseFloat(formData.payment_amount || '0'))}</div>
        </div>
        <div class="row" style="font-weight: bold;"><span>Balance Due:</span><span>${formatCurrency(calculated.pending_amount)}</span></div>
        <div class="footer">
          <p>Thank you for your payment!</p>
          <p>${new Date().toLocaleString('en-IN')}</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const isViewMode = mode === 'view';
  const isEditMode = mode === 'edit' || mode === 'create';

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {mode === 'create' ? 'New Bill' : mode === 'edit' ? 'Edit Bill' : 'View Bill'}
            </h1>
            <p className="text-gray-500 text-sm">{BILL_TYPE_LABELS[formData.bill_type]}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {isViewMode && (
            <>
              <button
                onClick={() => handlePrint(false)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-blue-700 transition-all"
              >
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button
                onClick={() => handlePrint(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                <Palette className="w-4 h-4" />
                B&W
              </button>
              <button
                onClick={handleSlipPrint}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                <Receipt className="w-4 h-4" />
                Slip
              </button>
              {parseFloat(formData.payment_amount || '0') > 0 && (
                <button
                  onClick={handlePaymentSlipPrint}
                  className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-xl font-semibold hover:bg-green-200 transition-all"
                >
                  <IndianRupee className="w-4 h-4" />
                  Receipt
                </button>
              )}
            </>
          )}
          {isEditMode && (
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all shadow-lg disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : 'Save Bill'}
            </button>
          )}
        </div>
      </div>

      {/* Bill Info */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Bill Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Hash className="w-4 h-4 inline mr-1" />
              Bill Number
            </label>
            <input
              type="text"
              value={formData.bill_number}
              onChange={(e) => setFormData({ ...formData, bill_number: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 font-mono font-bold"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bill Type</label>
            <select
              value={formData.bill_type}
              onChange={(e) => setFormData({ ...formData, bill_type: e.target.value as BillType })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="stone_sell">Stone Sell</option>
              <option value="stone_purchase">Stone Purchase</option>
              <option value="aggregate_sell">Aggregate Sell</option>
              <option value="aggregate_purchase">Aggregate Purchase</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="w-4 h-4 inline mr-1" />
              Bill Date
            </label>
            <input
              type="date"
              value={formData.bill_date}
              onChange={(e) => setFormData({ ...formData, bill_date: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Royalty Number</label>
            <input
              type="text"
              value={formData.royalty_number}
              onChange={(e) => setFormData({ ...formData, royalty_number: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="Optional"
            />
          </div>
        </div>
      </div>

      {/* Selections */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Select Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <User className="w-4 h-4 inline mr-1" />
              Party *
            </label>
            <select
              value={formData.party_id}
              onChange={(e) => setFormData({ ...formData, party_id: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="">Select Party</option>
              {parties.map(p => (
                <option key={p.id} value={p.id}>{p.name} - {p.mobile_number || 'No Phone'}</option>
              ))}
            </select>
            {selectedParty && (
              <div className="mt-2 text-xs text-gray-500 bg-gray-50 p-2 rounded-lg">
                <p><strong>Mobile:</strong> {selectedParty.mobile_number || 'N/A'}</p>
                <p><strong>Address:</strong> {selectedParty.address || 'N/A'}</p>
              </div>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Package className="w-4 h-4 inline mr-1" />
              Material *
            </label>
            <select
              value={formData.material_id}
              onChange={(e) => setFormData({ ...formData, material_id: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="">Select Material</option>
              {materials.map(m => (
                <option key={m.id} value={m.id}>{m.name} - {formatCurrency(m.rate_per_ton)}/ton</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Truck className="w-4 h-4 inline mr-1" />
              Truck
            </label>
            <select
              value={formData.truck_id}
              onChange={(e) => setFormData({ ...formData, truck_id: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="">Select Truck</option>
              <option value="no-vehicle">No Vehicle</option>
              {trucks.map(t => (
                <option key={t.id} value={t.id}>{t.truck_number} ({t.wheel_count || 0}W)</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Weights */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Scale className="w-5 h-5 text-green-500" />
          Weight Details
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gross Weight (Kg) *</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={formData.gross_weight_kg}
              onChange={(e) => setFormData({ ...formData, gross_weight_kg: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="0.00"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tare Weight (Kg) *</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={formData.tare_weight_kg}
              onChange={(e) => setFormData({ ...formData, tare_weight_kg: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="0.00"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Royalty Ton</label>
            <input
              type="number"
              min="0"
              step="0.001"
              value={formData.royalty_ton}
              onChange={(e) => setFormData({ ...formData, royalty_ton: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="0.000"
            />
          </div>
        </div>
      </div>

      {/* Calculations & Payment */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <IndianRupee className="w-5 h-5 text-green-500" />
            Calculations
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Net Weight</span>
              <span className="font-bold text-gray-900">{calculated.net_weight_ton.toFixed(3)} Ton</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Rate/Ton</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.rate_per_ton)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Material Amount</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.net_weight_ton * calculated.rate_per_ton)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Royalty Amount</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.royalty_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-xl text-white">
              <span className="font-semibold">Total Amount</span>
              <span className="text-2xl font-bold">{formatCurrency(calculated.total_amount)}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4">Payment Details</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Payment Amount (Rs)</label>
              <input
                type="number"
                min="0"
                step="1"
                value={formData.payment_amount}
                onChange={(e) => setFormData({ ...formData, payment_amount: e.target.value })}
                disabled={isViewMode}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100"
                placeholder="0"
              />
            </div>
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
              <span className="text-blue-700">Total Amount</span>
              <span className="font-semibold text-blue-900">{formatCurrency(calculated.total_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="text-green-700">Payment Received</span>
              <span className="font-semibold text-green-900">{formatCurrency(parseFloat(formData.payment_amount || '0'))}</span>
            </div>
            <div className={`flex justify-between items-center p-4 rounded-xl ${calculated.pending_amount > 0 ? 'bg-red-50' : 'bg-green-100'}`}>
              <span className={`font-semibold ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-green-700'}`}>
                {calculated.pending_amount > 0 ? 'Pending Amount' : 'Paid in Full'}
              </span>
              <span className={`text-2xl font-bold ${calculated.pending_amount > 0 ? 'text-red-900' : 'text-green-900'}`}>
                {formatCurrency(Math.max(0, calculated.pending_amount))}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
