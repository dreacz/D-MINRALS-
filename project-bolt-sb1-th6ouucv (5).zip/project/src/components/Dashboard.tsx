import { useEffect, useState } from 'react';
import {
  FileText,
  IndianRupee,
  Truck,
  AlertCircle,
  Plus,
  TrendingUp,
  Users,
  Package
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

type DashboardStats = {
  totalBills: number;
  totalAmount: number;
  totalTons: number;
  pendingAmount: number;
};

type BillType = 'stone_sell' | 'stone_purchase' | 'aggregate_sell' | 'aggregate_purchase';

const BILL_TYPE_LABELS: Record<BillType, string> = {
  'stone_sell': 'Stone Sell',
  'stone_purchase': 'Stone Purchase',
  'aggregate_sell': 'Aggregate Sell',
  'aggregate_purchase': 'Aggregate Purchase'
};

type View = 'dashboard' | 'parties' | 'materials' | 'trucks' | 'bills' | 'new-bill' | 'edit-bill' | 'view-bill';

interface DashboardProps {
  onNavigate: (view: View, billId?: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [stats, setStats] = useState<DashboardStats>({
    totalBills: 0,
    totalAmount: 0,
    totalTons: 0,
    pendingAmount: 0
  });
  const [recentBills, setRecentBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Get bill statistics
      const { data: billsData } = await supabase
        .from('bills')
        .select('total_amount, net_weight_ton, pending_amount');

      const totalBills = billsData?.length || 0;
      const totalAmount = billsData?.reduce((sum, b) => sum + (b.total_amount || 0), 0) || 0;
      const totalTons = billsData?.reduce((sum, b) => sum + (b.net_weight_ton || 0), 0) || 0;
      const pendingAmount = billsData?.reduce((sum, b) => sum + (b.pending_amount || 0), 0) || 0;

      setStats({ totalBills, totalAmount, totalTons, pendingAmount });

      // Get recent bills
      const { data: recentData } = await supabase
        .from('bills')
        .select(`
          id,
          bill_number,
          bill_date,
          bill_type,
          total_amount,
          pending_amount,
          party:parties(name),
          material:materials(name)
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      setRecentBills(recentData || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const newFormatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Company Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-6">
          <img
            src={COMPANY_PROFILE.logo}
            alt={COMPANY_PROFILE.name}
            className="w-24 h-24 object-contain bg-white rounded-xl p-2"
          />
          <div>
            <h1 className="text-3xl font-bold">{COMPANY_PROFILE.name}</h1>
            <p className="text-slate-300 mt-1">Parent: {COMPANY_PROFILE.parentCompany}</p>
            <div className="flex gap-6 mt-3 text-sm">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                {COMPANY_PROFILE.location}
              </span>
              <span>GST: {COMPANY_PROFILE.gst}</span>
              <span>Ph: {COMPANY_PROFILE.contact}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Total Bills</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalBills}</p>
            </div>
            <div className="bg-blue-100 p-4 rounded-xl">
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Total Amount</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{newFormatCurrency(stats.totalAmount)}</p>
            </div>
            <div className="bg-green-100 p-4 rounded-xl">
              <IndianRupee className="w-8 h-8 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Total Tons</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalTons.toFixed(2)}</p>
            </div>
            <div className="bg-amber-100 p-4 rounded-xl">
              <Truck className="w-8 h-8 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Pending Amount</p>
              <p className="text-3xl font-bold text-red-600 mt-2">{newFormatCurrency(stats.pendingAmount)}</p>
            </div>
            <div className="bg-red-100 p-4 rounded-xl">
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-4 mb-6">
          <TrendingUp className="w-6 h-6 text-amber-500" />
          <h2 className="text-xl font-bold text-gray-900">Quick Actions</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => onNavigate('new-bill')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
          >
            <Plus className="w-5 h-5" />
            New Bill
          </button>
          <button
            onClick={() => onNavigate('parties')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Users className="w-5 h-5" />
            Parties
          </button>
          <button
            onClick={() => onNavigate('materials')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Package className="w-5 h-5" />
            Materials
          </button>
          <button
            onClick={() => onNavigate('trucks')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Truck className="w-5 h-5" />
            Trucks
          </button>
        </div>
      </div>

      {/* Recent Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Recent Bills</h2>
            <button
              onClick={() => onNavigate('bills')}
              className="text-amber-600 hover:text-amber-700 font-semibold text-sm"
            >
              View All
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Bill No.</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Party</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Material</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Pending</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentBills.map((bill) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap font-semibold text-gray-900">#{bill.bill_number}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      bill.bill_type?.includes('stone') ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {BILL_TYPE_LABELS[bill.bill_type as BillType] || 'N/A'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.party?.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.material?.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right font-semibold text-gray-900">{newFormatCurrency(bill.total_amount)}</td>
                  <td className={`px-6 py-4 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {newFormatCurrency(bill.pending_amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <button
                      onClick={() => onNavigate('view-bill', bill.id)}
                      className="text-amber-600 hover:text-amber-700 font-semibold text-sm"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
              {recentBills.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    No bills found. Create your first bill to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
