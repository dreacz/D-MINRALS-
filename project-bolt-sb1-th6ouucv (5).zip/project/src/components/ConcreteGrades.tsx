import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Search,
  Layers,
  IndianRupee
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface ConcreteGrade {
  id: string;
  grade_name: string;
  price_per_mqb: number;
  carting_bhadu: number;
  created_at: string;
}

export default function ConcreteGrades() {
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingGrade, setEditingGrade] = useState<ConcreteGrade | null>(null);
  const [formData, setFormData] = useState({
    grade_name: '',
    price_per_mqb: '',
    carting_bhadu: ''
  });

  useEffect(() => {
    fetchGrades();
  }, []);

  const fetchGrades = async () => {
    try {
      const { data } = await supabase
        .from('concrete_grades')
        .select('*')
        .order('grade_name');
      setGrades(data || []);
    } catch (error) {
      console.error('Error fetching grades:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        grade_name: formData.grade_name,
        price_per_mqb: parseFloat(formData.price_per_mqb) || 0,
        carting_bhadu: parseFloat(formData.carting_bhadu) || 0,
        updated_at: new Date().toISOString()
      };

      if (editingGrade) {
        await supabase
          .from('concrete_grades')
          .update(payload)
          .eq('id', editingGrade.id);
      } else {
        await supabase.from('concrete_grades').insert([payload]);
      }
      resetForm();
      fetchGrades();
    } catch (error) {
      console.error('Error saving grade:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this grade?')) return;
    try {
      await supabase.from('concrete_grades').delete().eq('id', id);
      fetchGrades();
    } catch (error) {
      console.error('Error deleting grade:', error);
    }
  };

  const openEditModal = (grade: ConcreteGrade) => {
    setEditingGrade(grade);
    setFormData({
      grade_name: grade.grade_name,
      price_per_mqb: grade.price_per_mqb.toString(),
      carting_bhadu: grade.carting_bhadu.toString()
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      grade_name: '',
      price_per_mqb: '',
      carting_bhadu: ''
    });
    setEditingGrade(null);
    setShowModal(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const filteredGrades = grades.filter((grade) =>
    grade.grade_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-rose-100 p-3 rounded-xl">
            <Layers className="w-6 h-6 text-rose-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Concrete Grades</h1>
            <p className="text-gray-500 text-sm">{grades.length} grades registered</p>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-rose-500 to-rose-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-rose-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          Add Grade
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search concrete grades..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Grades Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGrades.map((grade) => (
          <div
            key={grade.id}
            className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-all group"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="bg-rose-50 p-3 rounded-xl">
                  <Layers className="w-8 h-8 text-rose-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{grade.grade_name}</h3>
                  <p className="text-rose-600 font-medium text-sm mt-1 flex items-center gap-1">
                    <IndianRupee className="w-3.5 h-3.5" />
                    {formatCurrency(grade.price_per_mqb)}/MQB
                  </p>
                  <p className="text-gray-500 text-sm mt-1">
                    Karting: {formatCurrency(grade.carting_bhadu)}/MQB
                  </p>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditModal(grade)}
                  className="p-2 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(grade.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredGrades.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            {searchTerm ? 'No grades found matching your search.' : 'No grades found. Add your first grade to get started.'}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900">
                {editingGrade ? 'Edit Grade' : 'Add New Grade'}
              </h2>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Layers className="w-4 h-4 inline mr-1" />
                  Grade Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.grade_name}
                  onChange={(e) => setFormData({ ...formData, grade_name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none"
                  placeholder="e.g., M20, M25, M30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <IndianRupee className="w-4 h-4 inline mr-1" />
                  Price per MQB *
                </label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  required
                  value={formData.price_per_mqb}
                  onChange={(e) => setFormData({ ...formData, price_per_mqb: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none"
                  placeholder="Enter price per MQB"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Karting Bhadu (per MQB)
                </label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={formData.carting_bhadu}
                  onChange={(e) => setFormData({ ...formData, carting_bhadu: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none"
                  placeholder="Enter carting charges per MQB"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-rose-500 to-rose-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-rose-700 transition-all"
                >
                  {editingGrade ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
