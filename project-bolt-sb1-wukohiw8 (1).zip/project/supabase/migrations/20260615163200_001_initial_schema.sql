-- Materials table
CREATE TABLE materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  price_per_ton DECIMAL(10,2) NOT NULL,
  royalty_per_ton DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trucks table
CREATE TABLE trucks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  truck_number TEXT NOT NULL UNIQUE,
  code_number TEXT,
  wheels INTEGER DEFAULT 10,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bills table
CREATE TABLE bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE,
  party_name TEXT NOT NULL,
  mobile_number TEXT,
  address TEXT,
  material_id UUID REFERENCES materials(id),
  truck_id UUID REFERENCES trucks(id),
  royalty_number TEXT,
  royalty_ton DECIMAL(10,3),
  gross_weight_kg DECIMAL(10,3),
  tare_weight_kg DECIMAL(10,3),
  net_weight_ton DECIMAL(10,3),
  royalty_amount DECIMAL(12,2),
  total_amount DECIMAL(12,2),
  payment_amount DECIMAL(12,2) DEFAULT 0,
  pending_amount DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  bill_date DATE DEFAULT CURRENT_DATE
);

-- Payments table
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES bills(id),
  amount DECIMAL(12,2) NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE trucks ENABLE ROW LEVEL SECURITY;
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies (public access for simplicity in this demo)
CREATE POLICY "materials_select" ON materials FOR SELECT USING (true);
CREATE POLICY "materials_insert" ON materials FOR INSERT WITH CHECK (true);
CREATE POLICY "materials_update" ON materials FOR UPDATE USING (true);
CREATE POLICY "materials_delete" ON materials FOR DELETE USING (true);

CREATE POLICY "trucks_select" ON trucks FOR SELECT USING (true);
CREATE POLICY "trucks_insert" ON trucks FOR INSERT WITH CHECK (true);
CREATE POLICY "trucks_update" ON trucks FOR UPDATE USING (true);
CREATE POLICY "trucks_delete" ON trucks FOR DELETE USING (true);

CREATE POLICY "bills_select" ON bills FOR SELECT USING (true);
CREATE POLICY "bills_insert" ON bills FOR INSERT WITH CHECK (true);
CREATE POLICY "bills_update" ON bills FOR UPDATE USING (true);
CREATE POLICY "bills_delete" ON bills FOR DELETE USING (true);

CREATE POLICY "payments_select" ON payments FOR SELECT USING (true);
CREATE POLICY "payments_insert" ON payments FOR INSERT WITH CHECK (true);
CREATE POLICY "payments_update" ON payments FOR UPDATE USING (true);
CREATE POLICY "payments_delete" ON payments FOR DELETE USING (true);