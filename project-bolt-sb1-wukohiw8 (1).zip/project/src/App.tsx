import { useState } from 'react'
import { CompanyProfile } from './components/CompanyProfile'
import { MaterialManagement } from './components/MaterialManagement'
import { TruckManagement } from './components/TruckManagement'
import { PartyManagement } from './components/PartyManagement'
import { BillDashboard } from './components/BillDashboard'
import { BillList } from './components/BillList'
import { DailySalesReport } from './components/DailySalesReport'
import { InstallPrompt } from './components/InstallPrompt'
import { LayoutDashboard, FileText, Package, Truck, BarChart2, Users } from 'lucide-react'

type Tab = 'dashboard' | 'bills' | 'report' | 'parties' | 'materials' | 'trucks'

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard')

  const navItems = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'bills' as Tab, label: 'Bills', icon: FileText },
    { id: 'report' as Tab, label: 'Sales Report', icon: BarChart2 },
    { id: 'parties' as Tab, label: 'Parties', icon: Users },
    { id: 'materials' as Tab, label: 'Materials', icon: Package },
    { id: 'trucks' as Tab, label: 'Trucks', icon: Truck },
  ]

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-slate-800">DEEP SILICA LLP</h1>
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium transition-colors text-sm ${
                    activeTab === item.id
                      ? 'bg-primary-500 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Mobile Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200">
        <div className="flex justify-around py-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-1 py-2 ${
                activeTab === item.id ? 'text-primary-500' : 'text-slate-400'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs font-medium" style={{ fontSize: '10px' }}>{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 pb-24 md:pb-6">
        <div className="mb-6">
          <CompanyProfile />
        </div>

        {activeTab === 'dashboard' && (
          <>
            <BillDashboard />
            <div className="mt-6">
              <BillList />
            </div>
          </>
        )}
        {activeTab === 'bills' && <BillList />}
        {activeTab === 'report' && <DailySalesReport />}
        {activeTab === 'parties' && <PartyManagement />}
        {activeTab === 'materials' && <MaterialManagement />}
        {activeTab === 'trucks' && <TruckManagement />}
      </main>

      {/* PWA Install Banner */}
      <InstallPrompt />
    </div>
  )
}

export default App
