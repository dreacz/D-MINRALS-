import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Party = {
  id: string
  name: string
  mobile: string | null
  address: string | null
  created_at: string
}

export type Material = {
  id: string
  name: string
  price_per_ton: number
  royalty_per_ton: number
  created_at: string
}

export type Truck = {
  id: string
  truck_number: string
  code_number: string | null
  wheels: number
  created_at: string
}

export type Bill = {
  id: string
  bill_number: string
  party_name: string
  mobile_number: string | null
  address: string | null
  material_id: string | null
  truck_id: string | null
  royalty_number: string | null
  royalty_ton: number | null
  gross_weight_kg: number | null
  tare_weight_kg: number | null
  net_weight_ton: number | null
  royalty_amount: number | null
  total_amount: number | null
  payment_amount: number
  pending_amount: number
  created_at: string
  bill_date: string
  material?: Material
  truck?: Truck
}

export type Payment = {
  id: string
  bill_id: string
  amount: number
  payment_date: string
  notes: string | null
  created_at: string
}
