import { forwardRef } from 'react'
import { Bill } from '../lib/supabase'

interface BillPrintProps {
  bill: Bill
}

export const BillPrint = forwardRef<HTMLDivElement, BillPrintProps>(({ bill }, ref) => {
  const materialAmount = (bill.net_weight_ton || 0) * (bill.material?.price_per_ton || 0)

  return (
    <div ref={ref} className="bg-white text-black p-8" style={{ width: '210mm', minHeight: '297mm', margin: '0 auto' }}>
      {/* Header */}
      <div className="text-center border-b-2 border-amber-600 pb-4 mb-6">
        <img
          src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjFGiVz8bNkI4cc7NRenm1Zzn28k8ivpah27eb9K5U21jMSnHuXKhDjYcdDhpiVdqRAViiqyhgMdP-eAFDfblYqWOGiLtRBCFRdwXgM97ET4Vp48KZ0K7Z-8lSXHmgvxXUYFdVg9vMzFX4Yc4HZRP5S1bFUi8VfmdzmirnKe2RFhyaYhVe3wcgVi6oIX03/s320/ChatGPT_Image_Apr_19__2026__09_37_53_PM-removebg-preview.png"
          alt="Logo" className="w-20 h-20 mx-auto mb-2"
        />
        <h1 className="text-2xl font-bold text-amber-700">DEEP SILICA LLP</h1>
        <p className="text-gray-600">Silica Sand & Silica Stone Suppliers</p>
        <p className="text-sm text-gray-500">Ratanpar, Gujarat | GST: 24L54OO641GX8Z</p>
      </div>

      {/* Bill Info */}
      <div className="flex justify-between mb-6">
        <div>
          <p className="font-bold text-lg">INVOICE</p>
          <p className="text-gray-600">{bill.bill_number}</p>
        </div>
        <div className="text-right">
          <p className="text-gray-600">Date: {new Date(bill.bill_date).toLocaleDateString('en-IN')}</p>
        </div>
      </div>

      {/* Party */}
      <div className="bg-amber-50 p-4 rounded mb-6 border border-amber-200">
        <p className="text-sm text-amber-700 font-medium">Bill To:</p>
        <p className="font-bold text-lg">{bill.party_name}</p>
        {bill.mobile_number && <p className="text-gray-600">Mobile: {bill.mobile_number}</p>}
        {bill.address && <p className="text-gray-500">{bill.address}</p>}
      </div>

      {/* Details */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="border p-2"><p className="text-xs text-gray-500">Material</p><p className="font-medium">{bill.material?.name || 'N/A'}</p></div>
        <div className="border p-2"><p className="text-xs text-gray-500">Truck</p><p className="font-medium">{bill.truck?.truck_number || 'N/A'}</p></div>
        <div className="border p-2"><p className="text-xs text-gray-500">Gross Weight</p><p className="font-medium">{bill.gross_weight_kg?.toLocaleString('en-IN')} Kg</p></div>
        <div className="border p-2"><p className="text-xs text-gray-500">Tare Weight</p><p className="font-medium">{bill.tare_weight_kg?.toLocaleString('en-IN')} Kg</p></div>
        <div className="border p-2 bg-amber-100"><p className="text-xs text-amber-700">Net Weight</p><p className="font-bold text-amber-800">{bill.net_weight_ton?.toFixed(3)} Ton</p></div>
        {bill.royalty_number && <div className="border p-2"><p className="text-xs text-gray-500">Royalty No.</p><p className="font-medium">{bill.royalty_number}</p></div>}
      </div>

      {/* Amount Table */}
      <table className="w-full border-collapse mb-6">
        <thead>
          <tr className="bg-amber-600 text-white">
            <th className="border p-2 text-left">Description</th>
            <th className="border p-2 text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border p-2">{bill.material?.name} ({bill.net_weight_ton?.toFixed(3)} Ton @ Rs {bill.material?.price_per_ton}/Ton)</td>
            <td className="border p-2 text-right">Rs {materialAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          </tr>
          {bill.royalty_amount && bill.royalty_amount > 0 && (
            <tr className="bg-gray-50">
              <td className="border p-2">Royalty ({bill.royalty_ton?.toFixed(3)} Ton @ Rs {bill.material?.royalty_per_ton}/Ton)</td>
              <td className="border p-2 text-right">Rs {bill.royalty_amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
            </tr>
          )}
          <tr className="bg-amber-100 font-bold">
            <td className="border p-2 text-right">TOTAL</td>
            <td className="border p-2 text-right text-amber-700">Rs {(bill.total_amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          </tr>
        </tbody>
      </table>

      {/* Payment */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="border p-3 bg-emerald-50"><p className="text-xs text-emerald-600">Paid</p><p className="font-bold text-emerald-700">Rs {bill.payment_amount.toLocaleString('en-IN')}</p></div>
        <div className={`border p-3 ${(bill.pending_amount || 0) > 0 ? 'bg-red-50' : 'bg-emerald-50'}`}>
          <p className={`text-xs ${(bill.pending_amount || 0) > 0 ? 'text-red-600' : 'text-emerald-600'}`}>Pending</p>
          <p className={`font-bold ${(bill.pending_amount || 0) > 0 ? 'text-red-700' : 'text-emerald-700'}`}>Rs {(bill.pending_amount || 0).toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-auto pt-6 border-t flex justify-between items-end">
        <div>
          <p className="text-sm text-gray-500">Contact:</p>
          <p className="font-medium">Mr. Deep Bhai - 9737468847</p>
          <p className="font-medium">Mr. Vinod Bhai - 6354152897</p>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-500 mb-6">For DEEP SILICA LLP</p>
          <p className="border-t pt-1 font-medium">Signature</p>
        </div>
      </div>
    </div>
  )
})

BillPrint.displayName = 'BillPrint'
