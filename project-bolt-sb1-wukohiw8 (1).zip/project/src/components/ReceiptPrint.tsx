import { Bill } from '../lib/supabase'

interface ReceiptPrintProps {
  bill: Bill
}

export function ReceiptPrint({ bill }: ReceiptPrintProps) {
  return (
    <div className="bg-white text-black p-4" style={{ width: '80mm', margin: '0 auto', fontFamily: 'monospace' }}>
      {/* Header */}
      <div className="text-center border-b border-dashed border-black pb-2 mb-2">
        <p className="font-bold text-lg">DEEP SILICA LLP</p>
        <p className="text-xs">Ratanpar, Gujarat</p>
        <p className="text-xs">GST: 24L54OO641GX8Z</p>
      </div>

      <p className="text-center font-bold border-b border-dashed border-black pb-2 mb-2">RECEIPT</p>

      {/* Info */}
      <div className="text-sm space-y-1 border-b border-dashed border-black pb-2 mb-2">
        <div className="flex justify-between"><span>Bill No:</span><span className="font-bold">{bill.bill_number}</span></div>
        <div className="flex justify-between"><span>Date:</span><span>{new Date(bill.bill_date).toLocaleDateString('en-IN')}</span></div>
        <p className="font-bold">Party: {bill.party_name}</p>
      </div>

      {/* Details */}
      <div className="text-sm space-y-1 border-b border-dashed border-black pb-2 mb-2">
        <div className="flex justify-between"><span>Material:</span><span>{bill.material?.name || 'N/A'}</span></div>
        <div className="flex justify-between"><span>Weight:</span><span>{bill.net_weight_ton?.toFixed(3)} Ton</span></div>
        <div className="flex justify-between"><span>Truck:</span><span>{bill.truck?.truck_number || 'N/A'}</span></div>
      </div>

      {/* Amount */}
      <div className="text-sm space-y-1 border-b-2 border-black pb-2 mb-2">
        <div className="flex justify-between font-bold"><span>Total:</span><span>Rs {(bill.total_amount || 0).toLocaleString('en-IN')}</span></div>
        <div className="flex justify-between"><span>Paid:</span><span className="font-bold">Rs {bill.payment_amount.toLocaleString('en-IN')}</span></div>
        <div className="flex justify-between font-bold border-t border-dashed border-black mt-1 pt-1">
          <span>Pending:</span><span>Rs {(bill.pending_amount || 0).toLocaleString('en-IN')}</span>
        </div>
      </div>

      {(bill.pending_amount || 0) === 0 ? (
        <div className="text-center font-bold py-2 bg-black text-white mb-2">FULLY PAID</div>
      ) : (
        <div className="text-center font-bold py-2 border-2 border-black mb-2">BALANCE DUE</div>
      )}

      <div className="text-center text-xs">
        <p className="font-bold">Thank you!</p>
        <p>Contact: 9737468847 / 6354152897</p>
      </div>
    </div>
  )
}
