import { useState, useEffect } from 'react'
import { supabase, Payment, Bill } from '../lib/supabase'
import { CreditCard, X, Save, IndianRupee, Trash2, CheckCircle } from 'lucide-react'

interface PaymentModalProps {
  bill: Bill
  onClose: () => void
  onSave: () => void
}

export function PaymentModal({ bill, onClose, onSave }: PaymentModalProps) {
  const [payments, setPayments] = useState<Payment[]>([])
  const [amount, setAmount] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => { fetchPayments() }, [bill.id])

  const fetchPayments = async () => {
    const { data } = await supabase.from('payments').select('*').eq('bill_id', bill.id).order('created_at', { ascending: false })
    if (data) setPayments(data)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const paymentAmount = parseFloat(amount)
    const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0) + paymentAmount
    await supabase.from('payments').insert({ bill_id: bill.id, amount: paymentAmount, notes: notes || null })
    await supabase.from('bills').update({ payment_amount: totalPaid, pending_amount: Math.max(0, (bill.total_amount || 0) - totalPaid) }).eq('id', bill.id)
    setAmount(''); setNotes(''); setLoading(false)
    fetchPayments(); onSave()
  }

  const handleDelete = async (paymentId: string, paymentAmount: number) => {
    if (confirm('Delete this payment?')) {
      await supabase.from('payments').delete().eq('id', paymentId)
      const newTotal = (bill.payment_amount || 0) - paymentAmount
      await supabase.from('bills').update({ payment_amount: newTotal, pending_amount: (bill.total_amount || 0) - newTotal }).eq('id', bill.id)
      fetchPayments(); onSave()
    }
  }

  const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0)
  const pendingAmount = (bill.total_amount || 0) - totalPaid

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-xl w-full max-w-md my-8">
        <div className="flex justify-between items-center p-4 border-b border-slate-200">
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Payment</h3>
            <p className="text-sm text-slate-500">{bill.bill_number} - {bill.party_name}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-4 space-y-4 max-h-[calc(100vh-150px)] overflow-y-auto">
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
              <p className="text-xs text-slate-500">Total</p>
              <p className="font-bold text-slate-800">Rs {(bill.total_amount || 0).toLocaleString('en-IN')}</p>
            </div>
            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-center">
              <p className="text-xs text-emerald-600">Paid</p>
              <p className="font-bold text-emerald-600">Rs {totalPaid.toLocaleString('en-IN')}</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg border border-red-200 text-center">
              <p className="text-xs text-red-600">Pending</p>
              <p className="font-bold text-red-600">Rs {pendingAmount.toLocaleString('en-IN')}</p>
            </div>
          </div>

          {pendingAmount > 0 && (
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Amount (Rs)</label>
                <input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" required />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Notes</label>
                <input type="text" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Cash, UPI, etc." className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" />
              </div>
              <button type="submit" disabled={loading} className="w-full bg-emerald-500 text-white py-2 rounded-lg font-medium hover:bg-emerald-600 flex items-center justify-center gap-2 disabled:opacity-50">
                {loading ? 'Saving...' : <><Save className="w-4 h-4" /> Add Payment</>}
              </button>
            </form>
          )}

          {pendingAmount <= 0 && (
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200 text-center">
              <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-emerald-600 font-medium">Fully Paid</p>
            </div>
          )}

          {payments.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-slate-700 mb-2">History</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {payments.map(p => (
                  <div key={p.id} className="flex justify-between items-center bg-slate-50 rounded-lg p-2">
                    <div>
                      <p className="font-medium text-slate-800">Rs {p.amount.toLocaleString('en-IN')}</p>
                      <p className="text-xs text-slate-500">{new Date(p.payment_date).toLocaleDateString('en-IN')}</p>
                    </div>
                    <button onClick={() => handleDelete(p.id, p.amount)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
