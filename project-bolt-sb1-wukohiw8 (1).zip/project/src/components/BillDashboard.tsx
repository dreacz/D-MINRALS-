import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { IndianRupee, FileText, Package, AlertCircle, RefreshCw } from 'lucide-react'

export function BillDashboard() {
  const [stats, setStats] = useState({
    totalBills: 0,
    totalAmount: 0,
    totalTons: 0,
    pendingAmount: 0
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    setLoading(true)
    const { data: bills } = await supabase.from('bills').select('*')

    if (bills) {
      setStats({
        totalBills: bills.length,
        totalAmount: bills.reduce((sum, b) => sum + (b.total_amount || 0), 0),
        totalTons: bills.reduce((sum, b) => sum + (b.net_weight_ton || 0), 0),
        pendingAmount: bills.reduce((sum, b) => sum + (b.pending_amount || 0), 0)
      })
    }
    setLoading(false)
  }

  const statCards = [
    { title: 'Total Bills', value: stats.totalBills, icon: FileText },
    { title: 'Total Amount', value: `Rs ${stats.totalAmount.toLocaleString('en-IN')}`, icon: IndianRupee },
    { title: 'Total Tons', value: `${stats.totalTons.toFixed(2)} Ton`, icon: Package },
    { title: 'Pending Amount', value: `Rs ${stats.pendingAmount.toLocaleString('en-IN')}`, icon: AlertCircle },
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Dashboard</h2>
        <button onClick={fetchStats} className="flex items-center gap-1 text-sm text-slate-600 hover:text-slate-800">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-5 h-5 text-primary-500" />
              <span className="text-sm text-slate-500">{stat.title}</span>
            </div>
            <p className="text-xl font-bold text-slate-800">{stat.value}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
