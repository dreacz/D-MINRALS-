import { useState, useEffect } from 'react'
import { supabase, Material, Truck, Party } from '../lib/supabase'
import { X, Save } from 'lucide-react'

interface BillFormProps {
  onClose: () => void
  onSave: () => void
  editingBill?: {
    id: string; bill_number: string; party_name: string; mobile_number: string | null; address: string | null;
    material_id: string | null; truck_id: string | null; royalty_number: string | null; royalty_ton: number | null;
    gross_weight_kg: number | null; tare_weight_kg: number | null;
  } | null
}

export function BillForm({ onClose, onSave, editingBill }: BillFormProps) {
  const [materials, setMaterials] = useState<Material[]>([])
  const [trucks, setTrucks] = useState<Truck[]>([])
  const [parties, setParties] = useState<Party[]>([])
  const [saving, setSaving] = useState(false)

  const [formData, setFormData] = useState({
    bill_number: editingBill?.bill_number || '',
    party_id: '',
    party_name: editingBill?.party_name || '',
    mobile_number: editingBill?.mobile_number || '',
    address: editingBill?.address || '',
    material_id: editingBill?.material_id || '',
    truck_id: editingBill?.truck_id || '',
    royalty_number: editingBill?.royalty_number || '',
    royalty_ton: editingBill?.royalty_ton?.toString() || '',
    gross_weight_kg: editingBill?.gross_weight_kg?.toString() || '',
    tare_weight_kg: editingBill?.tare_weight_kg?.toString() || '',
    payment_amount: ''
  })

  const [calculated, setCalculated] = useState({ net_weight_ton: 0, total_amount: 0, pending_amount: 0 })

  useEffect(() => {
    const fetchData = async () => {
      const [m, t, p] = await Promise.all([
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('parties').select('*').order('name')
      ])
      if (m.data) setMaterials(m.data)
      if (t.data) setTrucks(t.data)
      if (p.data) setParties(p.data)

      if (!editingBill) {
        const { data } = await supabase.from('bills').select('bill_number').order('created_at', { ascending: false }).limit(1)
        const nextNum = data && data.length > 0 ? parseInt(data[0].bill_number.replace('SIL-', '')) + 1 : 1
        setFormData(prev => ({ ...prev, bill_number: `SIL-${nextNum.toString().padStart(5, '0')}` }))
      }
    }
    fetchData()
  }, [])

  useEffect(() => {
    const m = materials.find(m => m.id === formData.material_id)
    const gross = parseFloat(formData.gross_weight_kg) || 0
    const tare = parseFloat(formData.tare_weight_kg) || 0
    const netTon = (gross - tare) / 1000
    const royaltyTon = parseFloat(formData.royalty_ton) || 0
    const payment = parseFloat(formData.payment_amount) || 0
    const total = (netTon * (m?.price_per_ton || 0)) + (royaltyTon * (m?.royalty_per_ton || 0))
    setCalculated({ net_weight_ton: netTon, total_amount: total, pending_amount: total - payment })
  }, [formData, materials])

  const handlePartyChange = (partyId: string) => {
    const party = parties.find(p => p.id === partyId)
    if (party) {
      setFormData(prev => ({
        ...prev,
        party_id: partyId,
        party_name: party.name,
        mobile_number: party.mobile || '',
        address: party.address || ''
      }))
    } else {
      setFormData(prev => ({ ...prev, party_id: '', party_name: '', mobile_number: '', address: '' }))
    }
  }

  const selectedTruck = trucks.find(t => t.id === formData.truck_id)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    const selectedMat = materials.find(m => m.id === formData.material_id)
    const billData = {
      bill_number: formData.bill_number,
      party_name: formData.party_name,
      mobile_number: formData.mobile_number || null,
      address: formData.address || null,
      material_id: formData.material_id || null,
      truck_id: formData.truck_id || null,
      royalty_number: formData.royalty_number || null,
      royalty_ton: parseFloat(formData.royalty_ton) || null,
      gross_weight_kg: parseFloat(formData.gross_weight_kg) || null,
      tare_weight_kg: parseFloat(formData.tare_weight_kg) || null,
      net_weight_ton: calculated.net_weight_ton || null,
      royalty_amount: (parseFloat(formData.royalty_ton) || 0) * (selectedMat?.royalty_per_ton || 0),
      total_amount: calculated.total_amount || null,
      payment_amount: parseFloat(formData.payment_amount) || 0,
      pending_amount: calculated.pending_amount || 0
    }
    if (editingBill) {
      await supabase.from('bills').update(billData).eq('id', editingBill.id)
    } else {
      await supabase.from('bills').insert(billData)
    }
    setSaving(false)
    onSave()
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-xl w-full max-w-2xl my-8">
        <div className="flex justify-between items-center p-4 border-b border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800">{editingBill ? 'Edit Bill' : 'New Bill'}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 max-h-[calc(100vh-150px)] overflow-y-auto">

          {/* Bill Number */}
          <div>
            <label className="block text-sm text-slate-600 mb-1">Bill Number</label>
            <input
              type="text"
              value={formData.bill_number}
              onChange={(e) => setFormData({ ...formData, bill_number: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              required
            />
          </div>

          {/* Party Select */}
          <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Party Details</p>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Select Party</label>
                <select
                  value={formData.party_id}
                  onChange={(e) => handlePartyChange(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800 bg-white"
                >
                  <option value="">-- Select Party --</option>
                  {parties.map(p => (
                    <option key={p.id} value={p.id}>{p.name}{p.mobile ? ` (${p.mobile})` : ''}</option>
                  ))}
                </select>
              </div>
              <div className="grid md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm text-slate-600 mb-1">Party Name *</label>
                  <input
                    type="text"
                    value={formData.party_name}
                    onChange={(e) => setFormData({ ...formData, party_name: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
                    placeholder="Or type manually"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-600 mb-1">Mobile</label>
                  <input
                    type="tel"
                    value={formData.mobile_number}
                    onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-600 mb-1">Address / Site</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Material & Truck */}
          <div className="grid md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-slate-600 mb-1">Material</label>
              <select
                value={formData.material_id}
                onChange={(e) => setFormData({ ...formData, material_id: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              >
                <option value="">Select Material</option>
                {materials.map(m => <option key={m.id} value={m.id}>{m.name} — Rs {m.price_per_ton}/ton</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-slate-600 mb-1">Truck</label>
              <select
                value={formData.truck_id}
                onChange={(e) => setFormData({ ...formData, truck_id: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              >
                <option value="">Select Truck</option>
                {trucks.map(t => <option key={t.id} value={t.id}>{t.truck_number} ({t.wheels} wheels)</option>)}
              </select>
              {selectedTruck && (
                <p className="text-xs text-slate-500 mt-1">Wheels: <span className="font-semibold text-slate-700">{selectedTruck.wheels}</span></p>
              )}
            </div>
          </div>

          {/* Weights */}
          <div className="grid md:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm text-slate-600 mb-1">Gross Weight (Kg)</label>
              <input
                type="number" step="0.001"
                value={formData.gross_weight_kg}
                onChange={(e) => setFormData({ ...formData, gross_weight_kg: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              />
            </div>
            <div>
              <label className="block text-sm text-slate-600 mb-1">Tare Weight (Kg)</label>
              <input
                type="number" step="0.001"
                value={formData.tare_weight_kg}
                onChange={(e) => setFormData({ ...formData, tare_weight_kg: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              />
            </div>
            <div>
              <label className="block text-sm text-slate-600 mb-1">Net Weight (Ton)</label>
              <div className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-slate-50 text-primary-600 font-semibold">
                {calculated.net_weight_ton.toFixed(3)}
              </div>
            </div>
          </div>

          {/* Royalty */}
          <div className="grid md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-slate-600 mb-1">Royalty Number</label>
              <input
                type="text"
                value={formData.royalty_number}
                onChange={(e) => setFormData({ ...formData, royalty_number: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              />
            </div>
            <div>
              <label className="block text-sm text-slate-600 mb-1">Royalty (Ton)</label>
              <input
                type="number" step="0.001"
                value={formData.royalty_ton}
                onChange={(e) => setFormData({ ...formData, royalty_ton: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
              />
            </div>
          </div>

          {/* Payment & Totals */}
          <div className="grid md:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm text-slate-600 mb-1">Payment Received (Rs)</label>
              <input
                type="number" step="0.01"
                value={formData.payment_amount}
                onChange={(e) => setFormData({ ...formData, payment_amount: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
                placeholder="0.00"
              />
            </div>
            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-xs text-emerald-600">Total Amount</p>
              <p className="font-bold text-emerald-700">Rs {calculated.total_amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
            </div>
            <div className={`p-3 rounded-lg border ${calculated.pending_amount > 0 ? 'bg-red-50 border-red-200' : 'bg-emerald-50 border-emerald-200'}`}>
              <p className={`text-xs ${calculated.pending_amount > 0 ? 'text-red-600' : 'text-emerald-600'}`}>Pending</p>
              <p className={`font-bold ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                Rs {calculated.pending_amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </p>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full bg-primary-500 text-white py-2.5 rounded-lg font-medium hover:bg-primary-600 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {saving ? 'Saving...' : <><Save className="w-4 h-4" /> Save Bill</>}
          </button>
        </form>
      </div>
    </div>
  )
}
