import { useState, useEffect, useRef } from 'react'
import { supabase, Bill } from '../lib/supabase'
import { Plus, RefreshCw, Pencil, Trash2, Printer, CreditCard, Receipt, MoreVertical } from 'lucide-react'
import { BillForm } from './BillForm'
import { PaymentModal } from './PaymentModal'
import { BillPrintBW } from './BillPrintBW'
import { ReceiptPrint } from './ReceiptPrint'

export function BillList() {
  const [bills, setBills] = useState<Bill[]>([])
  const [loading, setLoading] = useState(true)
  const [showBillForm, setShowBillForm] = useState(false)
  const [editingBill, setEditingBill] = useState<Bill | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null)
  const [printBill, setPrintBill] = useState<Bill | null>(null)
  const [receiptBill, setReceiptBill] = useState<Bill | null>(null)
  const [search, setSearch] = useState('')
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const printRef = useRef<HTMLDivElement>(null)

  useEffect(() => { fetchBills() }, [])

  const fetchBills = async () => {
    setLoading(true)
    const { data } = await supabase
      .from('bills')
      .select('*, material:materials(*), truck:trucks(*)')
      .order('created_at', { ascending: false })
    if (data) setBills(data)
    setLoading(false)
  }

  const handleEdit = (bill: Bill) => { setEditingBill(bill); setShowBillForm(true); setActiveMenu(null) }

  const handleDelete = async (id: string) => {
    if (confirm('Delete this bill?')) {
      await supabase.from('payments').delete().eq('bill_id', id)
      await supabase.from('bills').delete().eq('id', id)
      fetchBills()
    }
    setActiveMenu(null)
  }

  const handlePrint = (bill: Bill) => {
    setPrintBill(bill)
    setActiveMenu(null)
    setTimeout(() => { window.print(); setPrintBill(null) }, 100)
  }

  const handleReceipt = (bill: Bill) => {
    setReceiptBill(bill)
    setActiveMenu(null)
    setTimeout(() => { window.print(); setReceiptBill(null) }, 100)
  }

  const filteredBills = bills.filter(b =>
    b.bill_number.toLowerCase().includes(search.toLowerCase()) ||
    b.party_name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Bills</h2>
        <div className="flex gap-2">
          <button onClick={fetchBills} className="p-2 text-slate-600 hover:bg-slate-200 rounded-lg">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => { setEditingBill(null); setShowBillForm(true) }}
            className="flex items-center gap-1 bg-primary-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-primary-600"
          >
            <Plus className="w-4 h-4" /> New Bill
          </button>
        </div>
      </div>

      <div className="mb-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search bills..."
          className="w-full max-w-sm border border-slate-300 rounded-lg px-3 py-2 text-slate-800 text-sm"
        />
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">Loading...</div>
      ) : filteredBills.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">No bills</div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left p-3 text-slate-600 font-medium">Bill No.</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Party</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Date</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Truck</th>
                  <th className="text-right p-3 text-slate-600 font-medium">Amount</th>
                  <th className="text-right p-3 text-slate-600 font-medium">Pending</th>
                  <th className="text-center p-3 text-slate-600 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredBills.map((bill, idx) => (
                  <tr key={bill.id} className={`border-b border-slate-100 hover:bg-slate-50 ${idx % 2 === 0 ? '' : 'bg-slate-50/50'}`}>
                    <td className="p-3 font-medium text-slate-800">{bill.bill_number}</td>
                    <td className="p-3">
                      <p className="text-slate-800">{bill.party_name}</p>
                      {bill.mobile_number && <p className="text-xs text-slate-400">{bill.mobile_number}</p>}
                    </td>
                    <td className="p-3 text-slate-500">{new Date(bill.bill_date).toLocaleDateString('en-IN')}</td>
                    <td className="p-3 text-slate-500">{bill.truck?.truck_number || '—'}</td>
                    <td className="p-3 text-right text-emerald-600 font-medium">
                      Rs {(bill.total_amount || 0).toLocaleString('en-IN')}
                    </td>
                    <td className="p-3 text-right">
                      {(bill.pending_amount || 0) > 0
                        ? <span className="text-red-600">Rs {(bill.pending_amount || 0).toLocaleString('en-IN')}</span>
                        : <span className="text-emerald-600">Paid</span>}
                    </td>
                    <td className="p-3">
                      <div className="flex justify-center gap-1">
                        <button onClick={() => handleEdit(bill)} title="Edit" className="p-1.5 text-slate-400 hover:text-primary-500"><Pencil className="w-4 h-4" /></button>
                        <button onClick={() => handlePrint(bill)} title="Print (B&W)" className="p-1.5 text-slate-400 hover:text-slate-700"><Printer className="w-4 h-4" /></button>
                        <button onClick={() => { setSelectedBill(bill); setShowPaymentModal(true) }} title="Payment" className="p-1.5 text-slate-400 hover:text-emerald-500"><CreditCard className="w-4 h-4" /></button>
                        <button onClick={() => handleReceipt(bill)} title="Receipt" className="p-1.5 text-slate-400 hover:text-violet-500"><Receipt className="w-4 h-4" /></button>
                        <button onClick={() => handleDelete(bill.id)} title="Delete" className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {filteredBills.map((bill) => (
              <div key={bill.id} className="bg-white rounded-lg border border-slate-200 p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-medium text-slate-800">{bill.bill_number}</p>
                    <p className="text-xs text-slate-500">{new Date(bill.bill_date).toLocaleDateString('en-IN')}</p>
                  </div>
                  <div className="relative">
                    <button onClick={() => setActiveMenu(activeMenu === bill.id ? null : bill.id)} className="p-1 text-slate-400">
                      <MoreVertical className="w-5 h-5" />
                    </button>
                    {activeMenu === bill.id && (
                      <div className="absolute right-0 top-full mt-1 bg-white rounded-lg shadow-lg border border-slate-200 p-1 z-10 min-w-[130px]">
                        <button onClick={() => handleEdit(bill)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 rounded"><Pencil className="w-4 h-4" /> Edit</button>
                        <button onClick={() => handlePrint(bill)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 rounded"><Printer className="w-4 h-4" /> Print</button>
                        <button onClick={() => { setSelectedBill(bill); setShowPaymentModal(true); setActiveMenu(null) }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 rounded"><CreditCard className="w-4 h-4" /> Payment</button>
                        <button onClick={() => handleReceipt(bill)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 rounded"><Receipt className="w-4 h-4" /> Receipt</button>
                        <button onClick={() => handleDelete(bill.id)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /> Delete</button>
                      </div>
                    )}
                  </div>
                </div>
                <p className="text-slate-800 font-medium">{bill.party_name}</p>
                <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-100">
                  <span className="text-emerald-600 font-medium">Rs {(bill.total_amount || 0).toLocaleString('en-IN')}</span>
                  <span className={(bill.pending_amount || 0) > 0 ? 'text-red-600 text-sm' : 'text-emerald-600 text-sm'}>
                    {(bill.pending_amount || 0) > 0 ? `Rs ${bill.pending_amount.toLocaleString('en-IN')} pending` : 'Paid'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {showBillForm && (
        <BillForm
          onClose={() => { setShowBillForm(false); setEditingBill(null) }}
          onSave={fetchBills}
          editingBill={editingBill ? {
            id: editingBill.id, bill_number: editingBill.bill_number, party_name: editingBill.party_name,
            mobile_number: editingBill.mobile_number, address: editingBill.address,
            material_id: editingBill.material_id, truck_id: editingBill.truck_id,
            royalty_number: editingBill.royalty_number, royalty_ton: editingBill.royalty_ton,
            gross_weight_kg: editingBill.gross_weight_kg, tare_weight_kg: editingBill.tare_weight_kg
          } : null}
        />
      )}

      {showPaymentModal && selectedBill && (
        <PaymentModal bill={selectedBill} onClose={() => { setShowPaymentModal(false); setSelectedBill(null) }} onSave={fetchBills} />
      )}

      {printBill && <div className="print-area"><BillPrintBW bill={printBill} ref={printRef} /></div>}
      {receiptBill && <div className="print-area"><ReceiptPrint bill={receiptBill} /></div>}
    </div>
  )
}
