import { MapPin, Phone, FileText } from 'lucide-react'

export function CompanyProfile() {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6">
      <div className="flex flex-col md:flex-row items-center gap-6">
        <img
          src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjFGiVz8bNkI4cc7NRenm1Zzn28k8ivpah27eb9K5U21jMSnHuXKhDjYcdDhpiVdqRAViiqyhgMdP-eAFDfblYqWOGiLtRBCFRdwXgM97ET4Vp48KZ0K7Z-8lSXHmgvxXUYFdVg9vMzFX4Yc4HZRP5S1bFUi8VfmdzmirnKe2RFhyaYhVe3wcgVi6oIX03/s320/ChatGPT_Image_Apr_19__2026__09_37_53_PM-removebg-preview.png"
          alt="DEEP SILICA LLP Logo"
          className="w-24 h-24 object-contain"
        />

        <div className="flex-1 text-center md:text-left">
          <h1 className="text-2xl font-bold text-slate-800">DEEP SILICA LLP</h1>
          <p className="text-slate-500">Silica Sand & Silica Stone Suppliers</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 text-sm text-slate-600">
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <MapPin className="w-4 h-4 text-primary-500" />
              <span>Ratanpar, Gujarat</span>
            </div>
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <FileText className="w-4 h-4 text-primary-500" />
              <span>GST: 24L54OO641GX8Z</span>
            </div>
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <Phone className="w-4 h-4 text-primary-500" />
              <span>Mr. Deep Bhai - 9737468847</span>
            </div>
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <Phone className="w-4 h-4 text-primary-500" />
              <span>Mr. Vinod Bhai - 6354152897</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
