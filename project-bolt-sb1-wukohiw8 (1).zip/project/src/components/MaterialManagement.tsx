import { useState, useEffect } from 'react'
import { supabase, Material } from '../lib/supabase'
import { Package, Plus, Pencil, Trash2, X, Save, IndianRupee } from 'lucide-react'

export function MaterialManagement() {
  const [materials, setMaterials] = useState<Material[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null)
  const [formData, setFormData] = useState({ name: '', price_per_ton: '', royalty_per_ton: '' })
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchMaterials() }, [])

  const fetchMaterials = async () => {
    const { data } = await supabase.from('materials').select('*').order('created_at', { ascending: false })
    if (data) setMaterials(data)
    setLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (editingMaterial) {
      await supabase.from('materials').update({
        name: formData.name,
        price_per_ton: parseFloat(formData.price_per_ton),
        royalty_per_ton: parseFloat(formData.royalty_per_ton) || 0
      }).eq('id', editingMaterial.id)
    } else {
      await supabase.from('materials').insert({
        name: formData.name,
        price_per_ton: parseFloat(formData.price_per_ton),
        royalty_per_ton: parseFloat(formData.royalty_per_ton) || 0
      })
    }
    setIsModalOpen(false)
    setEditingMaterial(null)
    setFormData({ name: '', price_per_ton: '', royalty_per_ton: '' })
    fetchMaterials()
  }

  const handleEdit = (material: Material) => {
    setEditingMaterial(material)
    setFormData({
      name: material.name,
      price_per_ton: material.price_per_ton.toString(),
      royalty_per_ton: material.royalty_per_ton.toString()
    })
    setIsModalOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm('Delete this material?')) {
      await supabase.from('materials').delete().eq('id', id)
      fetchMaterials()
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Materials</h2>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-1 bg-primary-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-primary-600">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">Loading...</div>
      ) : materials.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">No materials</div>
      ) : (
        <div className="space-y-3">
          {materials.map((m) => (
            <div key={m.id} className="bg-white rounded-lg border border-slate-200 p-4 flex justify-between items-center">
              <div>
                <h3 className="font-medium text-slate-800">{m.name}</h3>
                <p className="text-sm text-slate-500">
                  Price: Rs {m.price_per_ton.toLocaleString('en-IN')}/ton | Royalty: Rs {m.royalty_per_ton.toLocaleString('en-IN')}/ton
                </p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => handleEdit(m)} className="p-2 text-slate-400 hover:text-primary-500"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => handleDelete(m.id)} className="p-2 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={(e) => e.target === e.currentTarget && setIsModalOpen(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-slate-800">{editingMaterial ? 'Edit Material' : 'Add Material'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Name</label>
                <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" placeholder="e.g., Silica Sand" required />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Price per Ton (Rs)</label>
                <input type="number" step="0.01" value={formData.price_per_ton} onChange={(e) => setFormData({ ...formData, price_per_ton: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" placeholder="0.00" required />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Royalty per Ton (Rs)</label>
                <input type="number" step="0.01" value={formData.royalty_per_ton} onChange={(e) => setFormData({ ...formData, royalty_per_ton: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" placeholder="0.00" />
              </div>
              <button type="submit" className="w-full bg-primary-500 text-white py-2 rounded-lg font-medium hover:bg-primary-600 flex items-center justify-center gap-2">
                <Save className="w-4 h-4" /> Save
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
