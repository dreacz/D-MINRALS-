import { useState, useEffect, useRef } from 'react'
import { supabase, Bill, Material, Truck, Party } from '../lib/supabase'
import { Search, Printer } from 'lucide-react'

export function DailySalesReport() {
  const [bills, setBills] = useState<Bill[]>([])
  const [materials, setMaterials] = useState<Material[]>([])
  const [trucks, setTrucks] = useState<Truck[]>([])
  const [parties, setParties] = useState<Party[]>([])
  const [loading, setLoading] = useState(false)
  const printRef = useRef<HTMLDivElement>(null)

  const today = new Date().toISOString().split('T')[0]

  const [filters, setFilters] = useState({
    start_date: today,
    end_date: today,
    party_id: '',
    truck_id: '',
    material_id: ''
  })

  useEffect(() => {
    const fetchMeta = async () => {
      const [m, t, p] = await Promise.all([
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('parties').select('*').order('name')
      ])
      if (m.data) setMaterials(m.data)
      if (t.data) setTrucks(t.data)
      if (p.data) setParties(p.data)
    }
    fetchMeta()
    fetchReport()
  }, [])

  const fetchReport = async () => {
    setLoading(true)
    let query = supabase
      .from('bills')
      .select('*, material:materials(*), truck:trucks(*)')
      .gte('bill_date', filters.start_date)
      .lte('bill_date', filters.end_date)
      .order('bill_date', { ascending: true })
      .order('created_at', { ascending: true })

    if (filters.material_id) query = query.eq('material_id', filters.material_id)
    if (filters.truck_id) query = query.eq('truck_id', filters.truck_id)

    const { data } = await query
    if (data) {
      let filtered = data
      if (filters.party_id) {
        const selectedParty = parties.find(p => p.id === filters.party_id)
        if (selectedParty) {
          filtered = data.filter(b => b.party_name.toLowerCase() === selectedParty.name.toLowerCase())
        }
      }
      setBills(filtered)
    }
    setLoading(false)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchReport()
  }

  const handlePrint = () => { window.print() }

  const totalTons = bills.reduce((sum, b) => sum + (b.net_weight_ton || 0), 0)
  const totalAmount = bills.reduce((sum, b) => sum + (b.total_amount || 0), 0)
  const totalPending = bills.reduce((sum, b) => sum + (b.pending_amount || 0), 0)

  const reportTitle =
    filters.start_date === filters.end_date
      ? `Sales Report — ${new Date(filters.start_date + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}`
      : `Sales Report — ${new Date(filters.start_date + 'T00:00:00').toLocaleDateString('en-IN')} to ${new Date(filters.end_date + 'T00:00:00').toLocaleDateString('en-IN')}`

  const selectedPartyName = filters.party_id ? parties.find(p => p.id === filters.party_id)?.name : ''
  const selectedMaterialName = filters.material_id ? materials.find(m => m.id === filters.material_id)?.name : ''
  const selectedTruckNumber = filters.truck_id ? trucks.find(t => t.id === filters.truck_id)?.truck_number : ''

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Daily Sales Report</h2>
        <button
          onClick={handlePrint}
          disabled={bills.length === 0}
          className="flex items-center gap-1 bg-slate-700 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-slate-800 disabled:opacity-40"
        >
          <Printer className="w-4 h-4" /> Print
        </button>
      </div>

      {/* Filters */}
      <form onSubmit={handleSearch} className="bg-white rounded-xl border border-slate-200 p-4 mb-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Start Date</label>
            <input
              type="date"
              value={filters.start_date}
              onChange={(e) => setFilters({ ...filters, start_date: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-2 py-2 text-sm text-slate-800"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">End Date</label>
            <input
              type="date"
              value={filters.end_date}
              onChange={(e) => setFilters({ ...filters, end_date: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-2 py-2 text-sm text-slate-800"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Party</label>
            <select
              value={filters.party_id}
              onChange={(e) => setFilters({ ...filters, party_id: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-2 py-2 text-sm text-slate-800"
            >
              <option value="">All Parties</option>
              {parties.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Truck</label>
            <select
              value={filters.truck_id}
              onChange={(e) => setFilters({ ...filters, truck_id: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-2 py-2 text-sm text-slate-800"
            >
              <option value="">All Trucks</option>
              {trucks.map(t => (
                <option key={t.id} value={t.id}>{t.truck_number}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Material</label>
            <select
              value={filters.material_id}
              onChange={(e) => setFilters({ ...filters, material_id: e.target.value })}
              className="w-full border border-slate-300 rounded-lg px-2 py-2 text-sm text-slate-800"
            >
              <option value="">All Materials</option>
              {materials.map(m => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-1 bg-primary-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-primary-600"
            >
              <Search className="w-4 h-4" /> Search
            </button>
          </div>
        </div>
      </form>

      {/* Summary cards */}
      {bills.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          <div className="bg-white rounded-lg border border-slate-200 p-3">
            <p className="text-xs text-slate-500">Total Bills</p>
            <p className="text-xl font-bold text-slate-800">{bills.length}</p>
          </div>
          <div className="bg-white rounded-lg border border-slate-200 p-3">
            <p className="text-xs text-slate-500">Total Tons</p>
            <p className="text-xl font-bold text-slate-800">{totalTons.toFixed(3)}</p>
          </div>
          <div className="bg-white rounded-lg border border-emerald-200 p-3">
            <p className="text-xs text-slate-500">Total Amount</p>
            <p className="text-xl font-bold text-emerald-600">Rs {totalAmount.toLocaleString('en-IN')}</p>
          </div>
          <div className="bg-white rounded-lg border border-red-200 p-3">
            <p className="text-xs text-slate-500">Pending</p>
            <p className="text-xl font-bold text-red-600">Rs {totalPending.toLocaleString('en-IN')}</p>
          </div>
        </div>
      )}

      {/* Screen Table */}
      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">Loading...</div>
      ) : bills.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">
          No records found. Adjust filters and click Search.
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left p-3 text-slate-600 font-medium">#</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Bill No.</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Date</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Party Name</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Site / Address</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Material</th>
                  <th className="text-left p-3 text-slate-600 font-medium">Truck No.</th>
                  <th className="text-right p-3 text-slate-600 font-medium">Net Wt (Ton)</th>
                  <th className="text-right p-3 text-slate-600 font-medium">Amount (Rs)</th>
                </tr>
              </thead>
              <tbody>
                {bills.map((bill, idx) => (
                  <tr key={bill.id} className={`border-b border-slate-100 ${idx % 2 === 0 ? '' : 'bg-slate-50'}`}>
                    <td className="p-3 text-slate-400">{idx + 1}</td>
                    <td className="p-3 font-medium text-slate-800">{bill.bill_number}</td>
                    <td className="p-3 text-slate-600">{new Date(bill.bill_date).toLocaleDateString('en-IN')}</td>
                    <td className="p-3 text-slate-800">{bill.party_name}</td>
                    <td className="p-3 text-slate-500">{bill.address || '—'}</td>
                    <td className="p-3 text-slate-700">{bill.material?.name || '—'}</td>
                    <td className="p-3 text-slate-700">{bill.truck?.truck_number || '—'}</td>
                    <td className="p-3 text-right font-medium text-slate-800">{(bill.net_weight_ton || 0).toFixed(3)}</td>
                    <td className="p-3 text-right font-medium text-emerald-600">{(bill.total_amount || 0).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 border-t-2 border-slate-300">
                <tr>
                  <td colSpan={7} className="p-3 font-bold text-slate-700 text-right">TOTAL ({bills.length} bills)</td>
                  <td className="p-3 text-right font-bold text-slate-800">{totalTons.toFixed(3)}</td>
                  <td className="p-3 text-right font-bold text-emerald-700">{totalAmount.toLocaleString('en-IN')}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Print Area */}
      {bills.length > 0 && (
        <div className="print-area" ref={printRef}>
          <div style={{ width: '100%', fontFamily: 'Arial, sans-serif', fontSize: '12px', padding: '20px' }}>
            {/* Print Header */}
            <div style={{ textAlign: 'center', borderBottom: '2px solid #1e293b', paddingBottom: '12px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '6px' }}>
                <img
                  src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjFGiVz8bNkI4cc7NRenm1Zzn28k8ivpah27eb9K5U21jMSnHuXKhDjYcdDhpiVdqRAViiqyhgMdP-eAFDfblYqWOGiLtRBCFRdwXgM97ET4Vp48KZ0K7Z-8lSXHmgvxXUYFdVg9vMzFX4Yc4HZRP5S1bFUi8VfmdzmirnKe2RFhyaYhVe3wcgVi6oIX03/s320/ChatGPT_Image_Apr_19__2026__09_37_53_PM-removebg-preview.png"
                  alt="Logo" style={{ width: '50px', height: '50px', objectFit: 'contain' }}
                />
                <div>
                  <div style={{ fontSize: '20px', fontWeight: 'bold' }}>DEEP SILICA LLP</div>
                  <div style={{ fontSize: '12px', color: '#555' }}>Silica Sand & Silica Stone Suppliers</div>
                  <div style={{ fontSize: '11px', color: '#777' }}>Ratanpar, Gujarat | GST: 24L54OO641GX8Z</div>
                </div>
              </div>
              <div style={{ fontSize: '15px', fontWeight: 'bold', marginTop: '6px' }}>{reportTitle}</div>
              {(selectedPartyName || selectedMaterialName || selectedTruckNumber) && (
                <div style={{ fontSize: '11px', color: '#555', marginTop: '3px' }}>
                  {selectedPartyName && `Party: ${selectedPartyName}`}
                  {selectedMaterialName && ` | Material: ${selectedMaterialName}`}
                  {selectedTruckNumber && ` | Truck: ${selectedTruckNumber}`}
                </div>
              )}
            </div>

            {/* Print Table */}
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#1e293b', color: 'white' }}>
                  {['#', 'Bill No.', 'Date', 'Party Name', 'Site / Address', 'Material', 'Truck No.', 'Net Wt (Ton)', 'Amount (Rs)'].map((h, i) => (
                    <th key={i} style={{ padding: '6px 8px', textAlign: i >= 7 ? 'right' : 'left', border: '1px solid #334155', fontSize: '11px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bills.map((bill, idx) => (
                  <tr key={bill.id} style={{ backgroundColor: idx % 2 === 0 ? '#fff' : '#f8fafc' }}>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', color: '#64748b' }}>{idx + 1}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', fontWeight: 'bold' }}>{bill.bill_number}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0' }}>{new Date(bill.bill_date).toLocaleDateString('en-IN')}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', fontWeight: '500' }}>{bill.party_name}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', color: '#64748b' }}>{bill.address || '—'}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0' }}>{bill.material?.name || '—'}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0' }}>{bill.truck?.truck_number || '—'}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', textAlign: 'right', fontWeight: '500' }}>{(bill.net_weight_ton || 0).toFixed(3)}</td>
                    <td style={{ padding: '5px 8px', border: '1px solid #e2e8f0', textAlign: 'right', fontWeight: '500' }}>{(bill.total_amount || 0).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr style={{ backgroundColor: '#1e293b', color: 'white', fontWeight: 'bold' }}>
                  <td colSpan={7} style={{ padding: '7px 8px', border: '1px solid #334155', textAlign: 'right', fontSize: '12px' }}>
                    TOTAL ({bills.length} bills)
                  </td>
                  <td style={{ padding: '7px 8px', border: '1px solid #334155', textAlign: 'right', fontSize: '12px' }}>{totalTons.toFixed(3)}</td>
                  <td style={{ padding: '7px 8px', border: '1px solid #334155', textAlign: 'right', fontSize: '12px' }}>Rs {totalAmount.toLocaleString('en-IN')}</td>
                </tr>
              </tfoot>
            </table>

            {/* Print Summary */}
            <div style={{ marginTop: '16px', display: 'flex', gap: '12px' }}>
              {[
                { label: 'Total Bills', value: String(bills.length), color: '#1e293b' },
                { label: 'Total Tons', value: totalTons.toFixed(3), color: '#1e293b' },
                { label: 'Total Amount', value: `Rs ${totalAmount.toLocaleString('en-IN')}`, color: '#16a34a' },
                { label: 'Pending Amount', value: `Rs ${totalPending.toLocaleString('en-IN')}`, color: '#dc2626' }
              ].map((s, i) => (
                <div key={i} style={{ flex: 1, padding: '8px', border: '1px solid #e2e8f0', borderRadius: '4px' }}>
                  <div style={{ fontSize: '10px', color: '#64748b' }}>{s.label}</div>
                  <div style={{ fontWeight: 'bold', fontSize: '14px', color: s.color, marginTop: '2px' }}>{s.value}</div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: '20px', paddingTop: '10px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#94a3b8' }}>
              <span>Printed: {new Date().toLocaleString('en-IN')}</span>
              <span>Contact: 9737468847 / 6354152897</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
