import { useState, useEffect } from 'react'
import { supabase, Truck } from '../lib/supabase'
import { Truck as TruckIcon, Plus, Pencil, Trash2, X, Save } from 'lucide-react'

export function TruckManagement() {
  const [trucks, setTrucks] = useState<Truck[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingTruck, setEditingTruck] = useState<Truck | null>(null)
  const [formData, setFormData] = useState({ truck_number: '', code_number: '', wheels: '10' })
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchTrucks() }, [])

  const fetchTrucks = async () => {
    const { data } = await supabase.from('trucks').select('*').order('created_at', { ascending: false })
    if (data) setTrucks(data)
    setLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (editingTruck) {
      await supabase.from('trucks').update({
        truck_number: formData.truck_number,
        code_number: formData.code_number || null,
        wheels: parseInt(formData.wheels)
      }).eq('id', editingTruck.id)
    } else {
      await supabase.from('trucks').insert({
        truck_number: formData.truck_number,
        code_number: formData.code_number || null,
        wheels: parseInt(formData.wheels)
      })
    }
    setIsModalOpen(false)
    setEditingTruck(null)
    setFormData({ truck_number: '', code_number: '', wheels: '10' })
    fetchTrucks()
  }

  const handleEdit = (truck: Truck) => {
    setEditingTruck(truck)
    setFormData({ truck_number: truck.truck_number, code_number: truck.code_number || '', wheels: truck.wheels.toString() })
    setIsModalOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm('Delete this truck?')) {
      await supabase.from('trucks').delete().eq('id', id)
      fetchTrucks()
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Trucks</h2>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-1 bg-emerald-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-emerald-600">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">Loading...</div>
      ) : trucks.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">No trucks</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {trucks.map((t) => (
            <div key={t.id} className="bg-white rounded-lg border border-slate-200 p-4">
              <div className="flex justify-between items-start mb-2">
                <TruckIcon className="w-5 h-5 text-emerald-500" />
                <div className="flex gap-1">
                  <button onClick={() => handleEdit(t)} className="p-1 text-slate-400 hover:text-emerald-500"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(t.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
              <h3 className="font-bold text-slate-800">{t.truck_number}</h3>
              <p className="text-sm text-slate-500">Code: {t.code_number || 'N/A'} | Wheels: {t.wheels}</p>
            </div>
          ))}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={(e) => e.target === e.currentTarget && setIsModalOpen(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-slate-800">{editingTruck ? 'Edit Truck' : 'Add Truck'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Truck Number</label>
                <input type="text" value={formData.truck_number} onChange={(e) => setFormData({ ...formData, truck_number: e.target.value.toUpperCase() })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800 uppercase" placeholder="GJ01AB1234" required />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Code Number</label>
                <input type="text" value={formData.code_number} onChange={(e) => setFormData({ ...formData, code_number: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Wheels</label>
                <select value={formData.wheels} onChange={(e) => setFormData({ ...formData, wheels: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800">
                  <option value="6">6</option>
                  <option value="10">10</option>
                  <option value="12">12</option>
                  <option value="14">14</option>
                  <option value="18">18</option>
                </select>
              </div>
              <button type="submit" className="w-full bg-emerald-500 text-white py-2 rounded-lg font-medium hover:bg-emerald-600 flex items-center justify-center gap-2">
                <Save className="w-4 h-4" /> Save
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
