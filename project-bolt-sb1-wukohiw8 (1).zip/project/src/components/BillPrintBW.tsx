import { forwardRef } from 'react'
import { Bill } from '../lib/supabase'

interface BillPrintBWProps {
  bill: Bill
}

export const BillPrintBW = forwardRef<HTMLDivElement, BillPrintBWProps>(({ bill }, ref) => {
  const materialAmount = (bill.net_weight_ton || 0) * (bill.material?.price_per_ton || 0)
  const royaltyAmount = bill.royalty_amount || 0
  const totalAmount = bill.total_amount || 0
  const paid = bill.payment_amount || 0
  const pending = bill.pending_amount || 0

  return (
    <div
      ref={ref}
      style={{
        width: '210mm',
        minHeight: '297mm',
        margin: '0 auto',
        padding: '12mm 14mm',
        fontFamily: 'Arial, Helvetica, sans-serif',
        fontSize: '12px',
        color: '#000',
        backgroundColor: '#fff',
        boxSizing: 'border-box',
      }}
    >
      {/* ── HEADER ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '8px' }}>
        <tbody>
          <tr>
            <td style={{ width: '70px', verticalAlign: 'middle' }}>
              <img
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjFGiVz8bNkI4cc7NRenm1Zzn28k8ivpah27eb9K5U21jMSnHuXKhDjYcdDhpiVdqRAViiqyhgMdP-eAFDfblYqWOGiLtRBCFRdwXgM97ET4Vp48KZ0K7Z-8lSXHmgvxXUYFdVg9vMzFX4Yc4HZRP5S1bFUi8VfmdzmirnKe2RFhyaYhVe3wcgVi6oIX03/s320/ChatGPT_Image_Apr_19__2026__09_37_53_PM-removebg-preview.png"
                alt="Logo"
                style={{ width: '60px', height: '60px', objectFit: 'contain' }}
              />
            </td>
            <td style={{ verticalAlign: 'middle', textAlign: 'center' }}>
              <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>DEEP SILICA LLP</div>
              <div style={{ fontSize: '11px', marginTop: '2px' }}>Silica Sand &amp; Silica Stone Suppliers</div>
              <div style={{ fontSize: '10px', color: '#444', marginTop: '2px' }}>
                Ratanpar, Gujarat &nbsp;|&nbsp; GST: 24L54OO641GX8Z &nbsp;|&nbsp; Ph: 9737468847 / 6354152897
              </div>
            </td>
            <td style={{ width: '90px', verticalAlign: 'middle', textAlign: 'right' }}>
              <div style={{ fontSize: '16px', fontWeight: 'bold' }}>INVOICE</div>
            </td>
          </tr>
        </tbody>
      </table>

      <div style={{ borderTop: '2px solid #000', marginBottom: '8px' }} />

      {/* ── BILL INFO ROW ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '8px', fontSize: '11px' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '25%' }}>
              <span style={{ color: '#555' }}>Bill No.:</span><br />
              <strong style={{ fontSize: '13px' }}>{bill.bill_number}</strong>
            </td>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '25%' }}>
              <span style={{ color: '#555' }}>Date:</span><br />
              <strong>{new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</strong>
            </td>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '25%' }}>
              <span style={{ color: '#555' }}>Truck No.:</span><br />
              <strong>{bill.truck?.truck_number || '—'}</strong>
            </td>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '25%' }}>
              <span style={{ color: '#555' }}>Wheels:</span><br />
              <strong>{bill.truck?.wheels ?? '—'}</strong>
            </td>
          </tr>
        </tbody>
      </table>

      {/* ── PARTY DETAILS ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '10px', fontSize: '11px' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '50%' }}>
              <span style={{ color: '#555' }}>Party Name:</span><br />
              <strong style={{ fontSize: '13px' }}>{bill.party_name}</strong>
              {bill.mobile_number && (
                <><br /><span style={{ color: '#555' }}>Mobile: </span>{bill.mobile_number}</>
              )}
            </td>
            <td style={{ border: '1px solid #000', padding: '4px 8px', width: '50%' }}>
              <span style={{ color: '#555' }}>Site / Address:</span><br />
              <strong>{bill.address || '—'}</strong>
            </td>
          </tr>
        </tbody>
      </table>

      {/* ── WEIGHT DETAILS TABLE ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '10px', fontSize: '11px' }}>
        <thead>
          <tr style={{ backgroundColor: '#1e293b', color: '#fff' }}>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'left' }}>Material</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>Gross Wt (Kg)</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>Tare Wt (Kg)</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>Net Wt (Kg)</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>Net Wt (Ton)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #000', padding: '5px 8px' }}><strong>{bill.material?.name || '—'}</strong></td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>
              {bill.gross_weight_kg?.toLocaleString('en-IN', { minimumFractionDigits: 3 }) || '—'}
            </td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>
              {bill.tare_weight_kg?.toLocaleString('en-IN', { minimumFractionDigits: 3 }) || '—'}
            </td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>
              {((bill.gross_weight_kg || 0) - (bill.tare_weight_kg || 0)).toLocaleString('en-IN', { minimumFractionDigits: 3 })}
            </td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>
              <strong>{(bill.net_weight_ton || 0).toFixed(3)}</strong>
            </td>
          </tr>
        </tbody>
      </table>

      {/* ── ROYALTY ROW ── */}
      {bill.royalty_number && (
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '10px', fontSize: '11px' }}>
          <tbody>
            <tr>
              <td style={{ border: '1px solid #000', padding: '4px 8px', width: '50%' }}>
                <span style={{ color: '#555' }}>Royalty No.:</span>&nbsp;<strong>{bill.royalty_number}</strong>
              </td>
              <td style={{ border: '1px solid #000', padding: '4px 8px', width: '50%' }}>
                <span style={{ color: '#555' }}>Royalty Ton:</span>&nbsp;<strong>{bill.royalty_ton?.toFixed(3) || '—'}</strong>
              </td>
            </tr>
          </tbody>
        </table>
      )}

      {/* ── AMOUNT TABLE ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '10px', fontSize: '11px' }}>
        <thead>
          <tr style={{ backgroundColor: '#1e293b', color: '#fff' }}>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'left', width: '50%' }}>Particulars</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right', width: '20%' }}>Qty (Ton)</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right', width: '15%' }}>Rate (Rs)</th>
            <th style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right', width: '15%' }}>Amount (Rs)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #000', padding: '5px 8px' }}>{bill.material?.name || 'Material'}</td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{(bill.net_weight_ton || 0).toFixed(3)}</td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{bill.material?.price_per_ton?.toLocaleString('en-IN') || '—'}</td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{materialAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          </tr>
          {royaltyAmount > 0 && (
            <tr style={{ backgroundColor: '#f8f8f8' }}>
              <td style={{ border: '1px solid #000', padding: '5px 8px' }}>Royalty Charge</td>
              <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{bill.royalty_ton?.toFixed(3) || '—'}</td>
              <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{bill.material?.royalty_per_ton?.toLocaleString('en-IN') || '—'}</td>
              <td style={{ border: '1px solid #000', padding: '5px 8px', textAlign: 'right' }}>{royaltyAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
            </tr>
          )}
        </tbody>
        <tfoot>
          <tr style={{ backgroundColor: '#e2e8f0', fontWeight: 'bold' }}>
            <td colSpan={3} style={{ border: '1px solid #000', padding: '6px 8px', textAlign: 'right', fontSize: '12px' }}>
              TOTAL AMOUNT
            </td>
            <td style={{ border: '1px solid #000', padding: '6px 8px', textAlign: 'right', fontSize: '13px' }}>
              Rs {totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </td>
          </tr>
        </tfoot>
      </table>

      {/* ── PAYMENT SUMMARY ── */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '16px', fontSize: '11px' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #000', padding: '5px 8px', width: '33.33%' }}>
              <span style={{ color: '#555' }}>Total Amount:</span><br />
              <strong style={{ fontSize: '13px' }}>Rs {totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </td>
            <td style={{ border: '1px solid #000', padding: '5px 8px', width: '33.33%' }}>
              <span style={{ color: '#555' }}>Paid Amount:</span><br />
              <strong style={{ fontSize: '13px' }}>Rs {paid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </td>
            <td style={{
              border: '2px solid #000',
              padding: '5px 8px',
              width: '33.33%',
              backgroundColor: pending > 0 ? '#fff0f0' : '#f0fff4'
            }}>
              <span style={{ color: '#555' }}>Pending Amount:</span><br />
              <strong style={{ fontSize: '14px' }}>Rs {pending.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </td>
          </tr>
        </tbody>
      </table>

      {/* ── FOOTER ── */}
      <div style={{ borderTop: '1px solid #000', paddingTop: '10px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 'auto' }}>
        <div style={{ fontSize: '11px' }}>
          <strong>DEEP SILICA LLP</strong><br />
          <span style={{ color: '#555' }}>Ph: 9737468847 (Deep Bhai) / 6354152897 (Vinod Bhai)</span><br />
          <span style={{ color: '#555' }}>Ratanpar, Gujarat</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ marginBottom: '24px', fontSize: '11px', color: '#555' }}>For DEEP SILICA LLP</div>
          <div style={{ borderTop: '1px solid #000', paddingTop: '4px', fontSize: '11px', width: '100px', textAlign: 'center' }}>
            Authorised Sign.
          </div>
        </div>
      </div>

      {/* ── TERMS ── */}
      <div style={{ marginTop: '10px', fontSize: '9px', color: '#777', borderTop: '1px dashed #ccc', paddingTop: '6px' }}>
        * This is a computer generated invoice. &nbsp;|&nbsp; Subject to Ratanpar Jurisdiction.
      </div>
    </div>
  )
})

BillPrintBW.displayName = 'BillPrintBW'
