import { useState, useEffect } from 'react'
import { supabase, Party } from '../lib/supabase'
import { Users, Plus, Pencil, Trash2, X, Save, Phone, MapPin } from 'lucide-react'

export function PartyManagement() {
  const [parties, setParties] = useState<Party[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingParty, setEditingParty] = useState<Party | null>(null)
  const [formData, setFormData] = useState({ name: '', mobile: '', address: '' })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => { fetchParties() }, [])

  const fetchParties = async () => {
    const { data } = await supabase.from('parties').select('*').order('name', { ascending: true })
    if (data) setParties(data)
    setLoading(false)
  }

  const openAdd = () => {
    setEditingParty(null)
    setFormData({ name: '', mobile: '', address: '' })
    setIsModalOpen(true)
  }

  const openEdit = (party: Party) => {
    setEditingParty(party)
    setFormData({ name: party.name, mobile: party.mobile || '', address: party.address || '' })
    setIsModalOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    const payload = {
      name: formData.name.trim(),
      mobile: formData.mobile.trim() || null,
      address: formData.address.trim() || null
    }
    if (editingParty) {
      await supabase.from('parties').update(payload).eq('id', editingParty.id)
    } else {
      await supabase.from('parties').insert(payload)
    }
    setSaving(false)
    setIsModalOpen(false)
    fetchParties()
  }

  const handleDelete = async (id: string) => {
    if (confirm('Delete this party?')) {
      await supabase.from('parties').delete().eq('id', id)
      fetchParties()
    }
  }

  const filtered = parties.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    (p.mobile && p.mobile.includes(search))
  )

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Parties</h2>
        <button onClick={openAdd} className="flex items-center gap-1 bg-primary-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-primary-600">
          <Plus className="w-4 h-4" /> Add Party
        </button>
      </div>

      <div className="mb-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search parties..."
          className="w-full max-w-sm border border-slate-300 rounded-lg px-3 py-2 text-slate-800 text-sm"
        />
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">No parties found</div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left p-3 text-slate-600 font-medium">#</th>
                <th className="text-left p-3 text-slate-600 font-medium">Party Name</th>
                <th className="text-left p-3 text-slate-600 font-medium">Mobile</th>
                <th className="text-left p-3 text-slate-600 font-medium">Address</th>
                <th className="text-center p-3 text-slate-600 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((party, idx) => (
                <tr key={party.id} className={`border-b border-slate-100 ${idx % 2 === 0 ? '' : 'bg-slate-50'}`}>
                  <td className="p-3 text-slate-400">{idx + 1}</td>
                  <td className="p-3 font-medium text-slate-800">{party.name}</td>
                  <td className="p-3 text-slate-600">{party.mobile || '—'}</td>
                  <td className="p-3 text-slate-500">{party.address || '—'}</td>
                  <td className="p-3">
                    <div className="flex justify-center gap-1">
                      <button onClick={() => openEdit(party)} className="p-1.5 text-slate-400 hover:text-primary-500"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(party.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={(e) => e.target === e.currentTarget && setIsModalOpen(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary-500" />
                <h3 className="text-lg font-semibold text-slate-800">{editingParty ? 'Edit Party' : 'Add Party'}</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Party Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800"
                  placeholder="e.g., Ram Enterprises"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Mobile</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="tel"
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg pl-10 pr-3 py-2 text-slate-800"
                    placeholder="10 digit mobile"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm text-slate-600 mb-1">Address</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg pl-10 pr-3 py-2 text-slate-800 resize-none"
                    rows={2}
                    placeholder="Site / location"
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={saving}
                className="w-full bg-primary-500 text-white py-2 rounded-lg font-medium hover:bg-primary-600 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Save className="w-4 h-4" /> {saving ? 'Saving...' : editingParty ? 'Update' : 'Save Party'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
