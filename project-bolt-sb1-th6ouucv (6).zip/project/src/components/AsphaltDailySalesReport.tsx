import { useEffect, useState } from 'react';
import {
  Printer,
  Search,
  FileText,
  MapPin,
  Layers,
  Calendar,
  Truck,
  Scale,
  IndianRupee
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface Site {
  id: string;
  site_name: string;
  site_number: string;
}

interface BituminousGrade {
  id: string;
  grade_name: string;
}

interface AsphaltBillData {
  id: string;
  bill_number: string;
  bill_date: string;
  quantity_ton: number;
  total_amount: number;
  site: { site_name: string; site_number: string } | null;
  truck: { truck_number: string } | null;
  bituminous_grade: { grade_name: string } | null;
}

export default function AsphaltDailySalesReport() {
  const [loading, setLoading] = useState(true);
  const [sites, setSites] = useState<Site[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [bills, setBills] = useState<AsphaltBillData[]>([]);

  const [filters, setFilters] = useState({
    site_id: '',
    grade_id: '',
    date_from: new Date().toISOString().split('T')[0],
    date_to: new Date().toISOString().split('T')[0]
  });

  const [filteredBills, setFilteredBills] = useState<AsphaltBillData[]>([]);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [bills, filters]);

  const fetchData = async () => {
    try {
      const [sitesRes, gradesRes, billsRes] = await Promise.all([
        supabase.from('sites').select('id, site_name, site_number').order('site_name'),
        supabase.from('bituminous_grades').select('id, grade_name').order('grade_name'),
        supabase
          .from('asphalt_bills')
          .select(`
            id,
            bill_number,
            bill_date,
            quantity_ton,
            total_amount,
            site:sites(site_name, site_number),
            truck:trucks(truck_number),
            bituminous_grade:bituminous_grades(grade_name)
          `)
          .order('bill_date', { ascending: false })
      ]);

      setSites(sitesRes.data || []);
      setGrades(gradesRes.data || []);
      setBills(billsRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...bills];

    if (filters.site_id) {
      filtered = filtered.filter(bill => bill.site && bill.site);
    }

    if (filters.date_from) {
      filtered = filtered.filter(bill => bill.bill_date >= filters.date_from);
    }

    if (filters.date_to) {
      filtered = filtered.filter(bill => bill.bill_date <= filters.date_to);
    }

    if (filters.site_id) {
      filtered = filtered.filter(bill => {
        const billSiteId = bills.find(b => b.id === bill.id);
        return true;
      });
    }

    setFilteredBills(filtered);
  };

  // Get bills filtered by site and grade from database
  const getFilteredList = () => {
    let list = [...bills];

    if (filters.site_id) {
      list = list.filter(bill => {
        const site = sites.find(s => s.site_name === bill.site?.site_name);
        return site?.id === filters.site_id;
      });
    }

    if (filters.grade_id) {
      list = list.filter(bill => {
        const grade = grades.find(g => g.grade_name === bill.bituminous_grade?.grade_name);
        return grade?.id === filters.grade_id;
      });
    }

    if (filters.date_from) {
      list = list.filter(bill => bill.bill_date >= filters.date_from);
    }

    if (filters.date_to) {
      list = list.filter(bill => bill.bill_date <= filters.date_to);
    }

    return list;
  };

  useEffect(() => {
    setFilteredBills(getFilteredList());
  }, [bills, filters, sites, grades]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Calculate totals
  const totals = filteredBills.reduce(
    (acc, bill) => ({
      totalTons: acc.totalTons + (bill.quantity_ton || 0),
      totalAmount: acc.totalAmount + (bill.total_amount || 0),
      count: acc.count + 1
    }),
    { totalTons: 0, totalAmount: 0, count: 0 }
  );

  const handlePrint = () => {
    const siteName = filters.site_id
      ? sites.find(s => s.id === filters.site_id)?.site_name || 'All Sites'
      : 'All Sites';
    const gradeName = filters.grade_id
      ? grades.find(g => g.id === filters.grade_id)?.grade_name || 'All Grades'
      : 'All Grades';

    const tableRows = filteredBills
      .map(
        (bill, index) => `
        <tr>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${index + 1}</td>
          <td style="padding: 8px; border: 1px solid #000;">${bill.bill_number}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.bill_date}</td>
          <td style="padding: 8px; border: 1px solid #000;">${bill.site?.site_name || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.truck?.truck_number || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.bituminous_grade?.grade_name || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: right;">${(bill.quantity_ton || 0).toFixed(3)}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: right;">${formatCurrency(bill.total_amount || 0)}</td>
        </tr>
      `
      )
      .join('');

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Asphalt Daily Sales Report</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 1000px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .title { font-size: 18px; font-weight: bold; text-align: center; margin: 20px 0; border: 1px solid #000; padding: 10px; }
          .filters { display: flex; justify-content: space-between; margin: 15px 0; font-size: 12px; }
          .filter-item { margin-right: 20px; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th { background: #f0f0f0; padding: 10px; border: 1px solid #000; font-weight: bold; text-align: center; }
          .totals { margin-top: 20px; padding: 15px; border: 2px solid #000; background: #f9f9f9; }
          .totals-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .totals-row.final { font-weight: bold; font-size: 16px; border-top: 1px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div style="font-size: 12px; color: #333; margin-top: 5px;">
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title">ASPHALT DAILY SALES REPORT</div>

        <div class="filters">
          <div class="filter-item"><strong>Site:</strong> ${siteName}</div>
          <div class="filter-item"><strong>Grade:</strong> ${gradeName}</div>
          <div class="filter-item"><strong>From:</strong> ${filters.date_from || 'N/A'}</div>
          <div class="filter-item"><strong>To:</strong> ${filters.date_to || 'N/A'}</div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 40px;">#</th>
              <th>Bill No.</th>
              <th>Date</th>
              <th>Site</th>
              <th>Truck</th>
              <th>Grade</th>
              <th>Qty (T)</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>

        <div class="totals">
          <div class="totals-row">
            <span>Total Bills:</span>
            <span>${totals.count}</span>
          </div>
          <div class="totals-row final">
            <span>Total Quantity:</span>
            <span>${totals.totalTons.toFixed(3)} Ton</span>
          </div>
          <div class="totals-row final">
            <span>Total Amount:</span>
            <span>${formatCurrency(totals.totalAmount)}</span>
          </div>
        </div>

        <div class="footer">
          <p>Generated on: ${new Date().toLocaleString()}</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-cyan-100 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-cyan-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Asphalt Daily Sales Report</h1>
            <p className="text-gray-500 text-sm">{totals.count} bills | {totals.totalTons.toFixed(3)} Tons | {formatCurrency(totals.totalAmount)}</p>
          </div>
        </div>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-xl font-semibold hover:from-cyan-600 hover:to-cyan-700 transition-all shadow-lg"
        >
          <Printer className="w-5 h-5" />
          Print Report
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <MapPin className="w-4 h-4 inline mr-1" />
              Site
            </label>
            <select
              value={filters.site_id}
              onChange={(e) => setFilters({ ...filters, site_id: e.target.value })}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
            >
              <option value="">All Sites</option>
              {sites.map((site) => (
                <option key={site.id} value={site.id}>
                  {site.site_name} - #{site.site_number}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Layers className="w-4 h-4 inline mr-1" />
              Bituminous Grade
            </label>
            <select
              value={filters.grade_id}
              onChange={(e) => setFilters({ ...filters, grade_id: e.target.value })}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
            >
              <option value="">All Grades</option>
              {grades.map((grade) => (
                <option key={grade.id} value={grade.id}>
                  {grade.grade_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Calendar className="w-4 h-4 inline mr-1" />
              From Date
            </label>
            <input
              type="date"
              value={filters.date_from}
              onChange={(e) => setFilters({ ...filters, date_from: e.target.value })}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Calendar className="w-4 h-4 inline mr-1" />
              To Date
            </label>
            <input
              type="date"
              value={filters.date_to}
              onChange={(e) => setFilters({ ...filters, date_to: e.target.value })}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
            />
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="bg-cyan-50 p-3 rounded-xl">
              <FileText className="w-6 h-6 text-cyan-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Total Bills</p>
              <p className="text-2xl font-bold text-gray-900">{totals.count}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="bg-green-50 p-3 rounded-xl">
              <Scale className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Total Tons</p>
              <p className="text-2xl font-bold text-gray-900">{totals.totalTons.toFixed(3)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="bg-amber-50 p-3 rounded-xl">
              <IndianRupee className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Total Amount</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(totals.totalAmount)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-cyan-600">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">#</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Site</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Truck</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Grade</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Qty (T)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBills.map((bill, index) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-gray-500">{index + 1}</td>
                  <td className="px-4 py-3 whitespace-nowrap font-bold text-gray-900">#{bill.bill_number}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.site?.site_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.truck?.truck_number || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bituminous_grade?.grade_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-medium text-gray-900">{(bill.quantity_ton || 0).toFixed(3)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatCurrency(bill.total_amount || 0)}</td>
                </tr>
              ))}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-gray-500">
                    No asphalt bills found for the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
            {filteredBills.length > 0 && (
              <tfoot className="bg-cyan-50">
                <tr>
                  <td colSpan={6} className="px-4 py-3 text-right font-semibold text-gray-900">
                    TOTAL
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-gray-900">
                    {totals.totalTons.toFixed(3)} T
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-gray-900">
                    {formatCurrency(totals.totalAmount)}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
}
